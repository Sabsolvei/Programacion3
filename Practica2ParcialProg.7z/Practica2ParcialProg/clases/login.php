<?php
use \Firebase\JWT\JWT;
require './composer/vendor/autoload.php';
require_once 'usuario.php';

class login
{

    public static function VerificarUsuario($email,$clave)
    {
        if(Usuario::TraerUnUsuarioEmail($email) != NULL)
        {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
            $consulta =$objetoAccesoDato->RetornarConsulta("select * from usuarios where Email = '$email' AND Clave = '$clave'");
            $consulta->execute();
            $usuarioBuscado= $consulta->fetchObject('Usuario');
            if($usuarioBuscado != NULL)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return -1;
        }

    }


}



// $key = "example_key";
// $token = array(
//     "iss" => "http://example.org",
//     "aud" => "http://example.com",
//     "iat" => 1356999524,
//     "nbf" => 1357000000,
//     "exp" => 20
// );

// $jwt = JWT::encode($token, $key);
// print_r($jwt);
// $decoded = JWT::decode($jwt, $key, array('HS256'));

// print_r($decoded);

// $decoded_array = (array) $decoded;

// JWT::$leeway = 60; // $leeway in seconds
// $decoded = JWT::decode($jwt, $key, array('HS256'));

?>