<?php

use \Firebase\JWT\JWT;
require_once 'usuario.php';
require_once 'AutentificadorJWT.php';
require '../composer/vendor/autoload.php';
//require_once 'IApiUsable.php';

class LoginApi extends Login //implements IApiUsable
{
    public function VerificarLoginApi($request, $response)
    {
        $ArrayDeParametros = $request->getParsedBody();
        $email = $ArrayDeParametros['email'];
        $clave = $ArrayDeParametros['clave'];
        $respuesta = Usuario::VerificarUsuario($email,$clave);
        if($respuesta == 1)
        {
            return AutentificadorJWT::CrearToken();
        }
        else if ($respuesta ==0)
        {
            return "Usuario o clave invàlidos.";
        }
        else
        {
            return "Usuario no registrado";
        }

        $response->getBody()->write($respuesta);
        return $response;
    }
}