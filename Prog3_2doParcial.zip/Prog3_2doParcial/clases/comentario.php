<?php
class comentario
{
  	public $email;
    public $titulo;
    public $comentario;
	public $ruta;
	


//TRAER COMENTARIOS	
public static function TraerTodosLosComentarios()
{
	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	$consulta =$objetoAccesoDato->RetornarConsulta("select * from comentarios");
	$consulta->execute();			
	return $consulta->fetchAll(PDO::FETCH_CLASS, "comentario");		
}

public static function TraerComentariosPorMail($email) 
{
	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	$consulta =$objetoAccesoDato->RetornarConsulta("select email, titulo, comentario, ruta from comentarios where email = '$email'");
	$consulta->execute();
	$comentarioBuscado= $consulta->fetchAll(PDO::FETCH_CLASS, "comentario");
	return $comentarioBuscado;				
}

public static function TraerComentarioPorTitulo($titulo) 
{
	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	$consulta =$objetoAccesoDato->RetornarConsulta("select email, titulo, comentario, ruta from comentarios where titulo = '$titulo'");
	$consulta->execute();
	$comentarioBuscado= $consulta->fetchAll(PDO::FETCH_CLASS, "comentario");	
	return $comentarioBuscado;			
}




//INSERTAR / MODIFICAR
	public function GuardarComentario()
	{
		if($this->id>0)
			{
				$this->ModificarComentarioParametros();
			}else {
				$this->InsertarElComentarioParametros();
			}
	}



//INSERTAR
	public function InsertarElComentarioParametros()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("INSERT into comentarios (email,titulo,comentario,ruta) values(:email,:titulo,:comentario,:ruta)");
		$consulta->bindValue(':email', $this->email, PDO::PARAM_STR);
		$consulta->bindValue(':titulo', $this->titulo, PDO::PARAM_STR);
		$consulta->bindValue(':comentario', $this->comentario, PDO::PARAM_STR);
		$consulta->bindValue(':ruta', $this->ruta, PDO::PARAM_STR);
		$consulta->execute();		
		return $objetoAccesoDato->RetornarUltimoIdInsertado();
	}
	
	public function InsertarElComentario()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("INSERT into comentarios (email,titulo,comentario,ruta) values('$this->email','$this->titulo','$this->comentario','$this->ruta')");
		$consulta->execute();
		return $objetoAccesoDato->RetornarUltimoIdInsertado();
	}




//MODIFICAR
	public function ModificarComentarioParametros()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
		$consulta =$objetoAccesoDato->RetornarConsulta("
			update comentarios 
			set nombre=:nombre,
			titulo=:titulo,
			comentario=:comentario,
			ruta=:ruta
			WHERE email=:email");
		//$consulta->bindValue(':id',$this->id, PDO::PARAM_INT);
		$consulta->bindValue(':titulo', $this->titulo, PDO::PARAM_STR);
		$consulta->bindValue(':email', $this->email, PDO::PARAM_STR);
		$consulta->bindValue(':comentario', $this->comentario, PDO::PARAM_STR);
		$consulta->bindValue(':ruta', $this->ruta, PDO::PARAM_STR);
		return $consulta->execute();
	}

	public function ModificarComentario()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("
			update comentarios 
			set ruta='$this->ruta',
			email='$this->email',
			titulo='$this->titulo'
			comentario='$this->comentario'
			WHERE email	='$this->email'");
		return $consulta->execute();
	}





//BORRAR
	public function BorrarComentario()
	{
	   $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
	   $comentarios = comentario::TraerComentarioPorTitulo($this->titulo);
	   if($comentarios != NULL)
	   {
		   foreach ($comentarios as $comentario) 
		   {
			   archivo::moverFotoABackup($comentario->ruta, $this->titulo);
		   }
		  
	   }
	   
	   $consulta = $objetoAccesoDato->RetornarConsulta("
		   delete 
		   from comentarios 				
		   WHERE titulo=:titulo");	
	   $consulta->bindValue(':titulo', $this->titulo, PDO::PARAM_STR);		
	   $consulta->execute();
	   return $consulta->rowCount();
	}


	public function mostrarDatos()
	{
	  	return "Metodo mostrar:" . $this->email . "  " . $this->titulo ."  " . $this->comentario . "  " . $this->ruta;
	}

}