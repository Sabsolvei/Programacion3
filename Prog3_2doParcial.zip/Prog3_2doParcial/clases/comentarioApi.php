<?php
require_once 'comentario.php';
require_once 'archivo.php';
require_once 'usuario.php';
//require_once 'IApiUsable.php';

class comentarioApi extends comentario //implements IApiUsable
{

	public function TraerUno($request, $response, $args) 
	{
			$email = $args['email'];
			$comentarios=comentario::TraerComentariosPorMail($email);
			$newResponse = $response->withJson($comentarios, 200);  
			return $newResponse;
	}
	
	public function traerTodos($request, $response, $args) 
	{
			$todosLosComentarios=comentario::TraerTodosLosComentarios();
			$response = $response->withJson($todosLosComentarios, 200);  
			return $response;
	}

	



	public function CargarUno($request, $response, $args) 
	{
			$ArrayDeParametros = $request->getParsedBody();
			$email = $ArrayDeParametros['email'];
			$titulo = $ArrayDeParametros['titulo'];
			$comentario = $ArrayDeParametros['comentario'];

			if(usuario::VerificarUsuarioPorMail($email) != NULL)
			{
				$miComentario = new comentario();
				$miComentario->email = $email;
				$miComentario->titulo = $titulo;
				$miComentario->comentario = $comentario;

				$ruta = $this->obtenerArchivo($request, $response, $titulo);
				if($ruta != NULL)
				{
					$miComentario->ruta = $ruta;
					$miComentario->InsertarElComentarioParametros();
					$response->getBody()->write("Se guardo el Comentario. ");
				}
				else
				{
					$response->getBody()->write("Error al intentar guardar archivo. ");
				}
			}
			else
			{
				$response->getBody()->write("Error: El email no existe en el registro de usuarios. ");
			}
			return $response;
	}



	public function obtenerArchivo($request, $response, $titulo) 
	{
		$uploadedFiles = $request->getUploadedFiles();
		$uploadedFile = $uploadedFiles['archivo']; //se obtiene asi por si sube mas de un archivo
		
		if ($uploadedFile->getError() === UPLOAD_ERR_OK) 
		{
			$ruta = archivo::moveUploadedFile($uploadedFile, $titulo);
			return $ruta;
		}
		else
		{
			return NULL;
		}	
	}


	
     
	public function ModificarUno($request, $response, $args) 
	{
			$objDelaRespuesta= new stdclass();
			$ComentarioAModificar = new comentario();
			$ArrayDeParametros = $request->getParsedBody();

			if(isset($ArrayDeParametros['email']))
			{
				$ComentarioAModificar = $ComentarioAModificar->TraerComentariosPorMail($ArrayDeParametros['email']);

				if($ComentarioAModificar != NULL)
				{

					if(isset($ArrayDeParametros['titulo'])) {
					$ComentarioAModificar->titulo = $ArrayDeParametros['titulo'];
					}
					if(isset($ArrayDeParametros['comentario'])) {
						$ComentarioAModificar->comentario = $ArrayDeParametros['comentario'];
					}

					//PARA MODIFICAR IMAGEN DEBO PASAR EL METODO A POST (PARA PODER USAR FORM-DATA, PUT SOLO USA WWW-URLENCODED)
					// $ruta = $this->obtenerArchivo($request, $response, $ComentarioAModificar->titulo);
					// if($ruta != 0) {
					// 	$ComentarioAModificar->ruta = $ruta;
					// }

					$resultado = $ComentarioAModificar->ModificarComentarioParametros();
					$objDelaRespuesta->resultado=$resultado;

				}

				else { $objDelaRespuesta->resultado= "El email ingresado no existe."; }
				
			}
			
			else { $objDelaRespuesta->resultado= "Debe ingresar un email."; }

			return $response->withJson($objDelaRespuesta, 200);		
	}
	



	public function BorrarUno($request, $response, $args) 
	{
			$ArrayDeParametros = $request->getParsedBody(); //form-urlencoded
			$titulo = $ArrayDeParametros['titulo'];

			$Comentario = new comentario();
			$Comentario->titulo = $titulo;
			$cantidadDeBorrados = $Comentario->BorrarComentario();

			$objDelaRespuesta = new stdclass();
			$objDelaRespuesta->cantidad = $cantidadDeBorrados;
			if($cantidadDeBorrados > 0)
			{
				$objDelaRespuesta->resultado = "El Comentario con titulo: ".$titulo." fue eliminado exitosamente";
			}
			else
			{
				$objDelaRespuesta->resultado = "No Borro nada!!!";
			}
			$newResponse = $response->withJson($objDelaRespuesta, 200);  
			return $newResponse;
	}





	public function generarTabla($request, $response, $args) 
	{ //GET
				$comentarios;
				$usuarios;
				$grilla = '<table class="table">
				<thead style="background:rgb(14, 26, 112);color:#fff;">
					<tr>
						<th>  EMAIL  	</th>
						<th>  EDAD   	</th>
						<th>  TITULO	</th>
						<th>  COMENTARIO</th>
						<th>  FOTO		</th>
					</tr>  
				</thead>';

				if(isset($args['titulo']))
				{
					$titulo = $args['titulo'];
					$comentarios = comentario::TraerComentarioPorTitulo($titulo);
					//$usuarios = usuario::TraerUnUsuarioPorMail($email);
				}
				else if(isset($args['email']))
				{
					$email = $args['email'];
					$comentarios = comentario::TraerComentariosPorMail($email);
					//$usuarios = usuario::TraerUnUsuarioPorMail($email);
				}
				else
				{
					$comentarios = comentario::TraerTodosLosComentarios();
				}

				foreach($comentarios as $comentario)
				{
					$edad = "-";
					$user = usuario::TraerUnUsuarioPorMail($comentario->email);
					if($user != NULL) { $edad = $user->edad; }

				$grilla .= "<tr>
				<td>".$comentario->email."</td>
				<td>".$edad."</td>
				<td>".$comentario->titulo."</td>
				<td>".$comentario->comentario."</td>
				<td><img src=" . (isset($args['titulo']) ? '../../' : (isset($args['email'])? '../': '' )) .'../'. $comentario->ruta." width='100px' height='100px'/></td>
				</tr>";
				}
				return $grilla;
	}
}