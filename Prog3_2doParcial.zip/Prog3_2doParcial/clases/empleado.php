<?php
class empleado
{
	public $id;
    public $nombre;
    public $apellido;
  	public $email;
    public $legajo;
    public $perfil;
    public $clave;
    public $ruta;




//TRAER empleadoS
public static function TraerTodosLosempleados()
{
	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	$consulta =$objetoAccesoDato->RetornarConsulta("select * from empleados");
	$consulta->execute();			
	return $consulta->fetchAll(PDO::FETCH_CLASS, "empleado");		
}

public static function TraerUnempleado($id) 
{
	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	$consulta =$objetoAccesoDato->RetornarConsulta("select id, nombre,apellido, email, legajo, perfil, clave from empleados where id = $id");
	$consulta->execute();
	$empleadoBuscado= $consulta->fetchObject('empleado');
	return $empleadoBuscado;				
}

public static function TraerUnempleadoPorMail($email) 
{
	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	$consulta =$objetoAccesoDato->RetornarConsulta("select id, nombre,apellido email, legajo, perfil, clave from empleados where email = '$email'");
	$consulta->execute();
	$empleadoBuscado= $consulta->fetchObject('empleado');
	return $empleadoBuscado;				
}





//INSERTAR MODIFICAR
	public function Guardarempleado()
	{
		if($this->id>0)
			{
				$this->ModificarempleadoParametros();
			}else {
				$this->InsertarElempleadoParametros();
			}
	}



//INSERTAR
	public function InsertarElempleadoParametros()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("INSERT into empleados  (nombre,apellido,email,legajo,perfil,clave,ruta) values(:nombre,:apellido,:email,:legajo,:perfil,:clave,:ruta)");
		$consulta->bindValue(':nombre',$this->nombre, PDO::PARAM_STR);
        $consulta->bindValue(':apellido', $this->apellido, PDO::PARAM_STR);
        $consulta->bindValue(':email', $this->email, PDO::PARAM_STR);
		$consulta->bindValue(':legajo', $this->legajo, PDO::PARAM_INT);
		$consulta->bindValue(':perfil', $this->perfil, PDO::PARAM_STR);
		$passHash = password_hash($this->clave, PASSWORD_BCRYPT);
        $consulta->bindValue(':clave', $passHash, PDO::PARAM_STR);
        $consulta->bindValue(':ruta', $this->ruta, PDO::PARAM_STR);
		$consulta->execute();		
		return $objetoAccesoDato->RetornarUltimoIdInsertado();
	}

	public function InsertarElempleado()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("INSERT into empleados (nombre,apellido,email,legajo,perfil,clave)values('$this->nombre','$this->apellido','$this->email','$this->legajo','$this->perfil','$this->clave')");
		$consulta->execute();
		return $objetoAccesoDato->RetornarUltimoIdInsertado();
	}




//MODIFICAR
	public function ModificarempleadoParametros()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();

		$consulta =$objetoAccesoDato->RetornarConsulta("
			update empleados 
			set nombre=:nombre,
			legajo=:legajo,
			perfil=:perfil,
			clave=:clave
			WHERE email=:email");
		//$consulta->bindValue(':id',$this->id, PDO::PARAM_INT);
		$consulta->bindValue(':nombre',$this->nombre, PDO::PARAM_STR);
		$consulta->bindValue(':legajo', $this->legajo, PDO::PARAM_INT);
		$consulta->bindValue(':email', $this->email, PDO::PARAM_STR);
		$consulta->bindValue(':perfil', $this->perfil, PDO::PARAM_STR);
		$passHash = password_hash($this->clave, PASSWORD_BCRYPT);
		$consulta->bindValue(':clave', $passHash, PDO::PARAM_STR);
		return $consulta->execute();
	}

	public function Modificarempleado()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("
			update empleados 
			set nombre='$this->nombre',
			email='$this->email',
			legajo='$this->legajo'
			perfil='$this->perfil'
			WHERE id='$this->id'");
		return $consulta->execute();
	}




//BORRAR
  	public function Borrarempleado()
	 {
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("
			delete 
			from empleados 				
			WHERE id=:id");	
		$consulta->bindValue(':id',$this->id, PDO::PARAM_INT);		
		$consulta->execute();
		return $consulta->rowCount();
	 }

	public static function BorrarempleadoPorEmail($email)
	 {
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("
			delete 
			from empleados 				
			WHERE email=:email");	
		$consulta->bindValue(':email',$email, PDO::PARAM_STR);		
		$consulta->execute();
		return $consulta->rowCount();
     }
     
		 



//VERIFICAR empleado EMAIL/ CLAVE
	public static function verificarempleadoPorMail($email)
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
		$resp = new stdClass();
		$consulta =$objetoAccesoDato->RetornarConsulta("select * from empleados where email = '$email'");
		$consulta->execute();
		$empleado= $consulta->fetchObject('empleado');
		return $empleado;
	}

	public static function esValido($email, $clave) 
	{
		$resp->empleado = NULL;
		$resp->msj= NULL;
		$resp->estado= 0;
		$empleado= empleado::verificarempleadoPorMail($email);
		if($empleado != NULL)
		{
			$verify = password_verify($clave, $empleado->clave);
			if($verify)
			{
				$resp->empleado = $empleado;
				$resp->msj = "Valido: true";
				//$resp->perfil = $empleado->perfil;
				$resp->estado = 1;
			}
			else
			{
				$resp->msj = "Valido: false";
				$resp->estado = 0;
			}
		}
		else
		{
			$resp->msj = "Email no registrado";
			$resp->estado = 0;
		}
		
		return $resp;		
	}

	

	public function mostrarDatos()
	{
	  	return "Metodo mostrar:".$this->nombre."  ".$this->email."  ".$this->legajo."  ".$this->perfil."  ".$this->clave;
	}

}