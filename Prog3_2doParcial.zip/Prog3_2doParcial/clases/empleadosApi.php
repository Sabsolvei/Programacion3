<?php
require_once 'empleado.php';
require_once 'archivo.php';


class empleadosApi //extends empleado //implements IApiUsable
{


	// public function TraerUno($request, $response, $args) 
	// {
	// 		$id = $args['id'];
	// 		$elempleado = empleado::TraerUnempleado($id);
	// 		$newResponse = $response->withJson($elempleado, 200);  
	// 		return $newResponse;
	// }
	
	public function traerTodos($request, $response, $args) 
	{
			$todosLosempleados = empleado::TraerTodosLosempleados();
			$response = $response->withJson($todosLosempleados, 200);  
			return $response;
	}
	



	public function CargarUno($request, $response, $args) 
	{
			$ArrayDeParametros = $request->getParsedBody();
            $nombre = $ArrayDeParametros['nombre'];
            $apellido = $ArrayDeParametros['apellido'];
			$email = $ArrayDeParametros['email'];
			$legajo = $ArrayDeParametros['legajo'];
			$perfil = $ArrayDeParametros['perfil'];
			$clave = $ArrayDeParametros['clave'];
			
			$miEmpleado = new empleado();
            $miEmpleado->nombre=$nombre;
            $miEmpleado->apellido=$apellido;
			$miEmpleado->email=$email;
			$miEmpleado->legajo=$legajo;
			$miEmpleado->perfil=$perfil;
			$miEmpleado->clave=$clave;
            $ruta = $this->obtenerArchivo($request, $response, $nombre);
            if($ruta != NULL)
            {
                $miEmpleado->ruta = $ruta;
                $miEmpleado->InsertarElempleadoParametros();
                $response->getBody()->write("Se guardo el Empleado. ");
            }
            else
            {
                $response->getBody()->write("Error al intentar guardar archivo. ");
            }

			return $response;
	}
	

    public function obtenerArchivo($request, $response, $nombre) 
	{
		$uploadedFiles = $request->getUploadedFiles();
		$uploadedFile = $uploadedFiles['archivo'];
		
		if ($uploadedFile->getError() === UPLOAD_ERR_OK) 
		{
			$ruta = archivo::moveUploadedFile($uploadedFile, $nombre);
			return $ruta;
		}
		else
		{
			return NULL;
		}	
	}

    // public function ModificarUno($request, $response, $args) 
    // {
    //         $ArrayDeParametros = $request->getParsedBody();
        
    //         $empleadoAModificar = new empleado();
    //         $empleadoAModificar = $empleadoAModificar->TraerUnempleadoPorMail($ArrayDeParametros['email']);
    //         if(isset($ArrayDeParametros['nombre']))
    //         {
    //             $empleadoAModificar->nombre = $ArrayDeParametros['nombre'];
    //         }

    //         if(isset($ArrayDeParametros['legajo']))
    //         {
    //             $empleadoAModificar->legajo = $ArrayDeParametros['legajo'];
    //         }

    //         if(isset($ArrayDeParametros['perfil']))
    //         {
    //             $empleadoAModificar->perfil = $ArrayDeParametros['perfil'];
    //         }

    //         if(isset($ArrayDeParametros['clave']))
    //         {
    //             $empleadoAModificar->clave = $ArrayDeParametros['clave'];
    //         }

    //         $resultado =$empleadoAModificar->ModificarempleadoParametros();
    //         $objDelaRespuesta= new stdclass();
    //         $objDelaRespuesta->resultado=$resultado;
    //         return $response->withJson($objDelaRespuesta, 200);		
    // }




    // public function BorrarUno($request, $response, $args) 
    // {
    //         $ArrayDeParametros = $request->getParsedBody(); //form-urlencoded
    //         $id=$ArrayDeParametros['id'];
    //         $empleado= new empleado();
    //         $empleado->id=$id;
    //         $cantidadDeBorrados=$empleado->Borrarempleado();

    //         $objDelaRespuesta= new stdclass();
    //         $objDelaRespuesta->cantidad=$cantidadDeBorrados;
    //         if($cantidadDeBorrados>0)
    //         {
    //                 $objDelaRespuesta->resultado="El empleado con id: ".$id." fue eliminado exitosamente";
    //         }
    //         else
    //         {
    //             $objDelaRespuesta->resultado="no Borro nada!!!";
    //         }
    //         $newResponse = $response->withJson($objDelaRespuesta, 200);  
    //         return $newResponse;
    // }
	


}