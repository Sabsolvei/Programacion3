<?php
require_once 'empleado.php';
require_once 'archivo.php';

class loginApi//extends login
{

    public function login($request, $response, $args) 
    {
        $token="";
        $ArrayDeParametros = $request->getParsedBody();
        
        if(isset( $ArrayDeParametros['email']) && isset( $ArrayDeParametros['clave']) )
        {
                $email=$ArrayDeParametros['email'];
                $clave= $ArrayDeParametros['clave'];
                
                $validacion = empleado::esValido($email,$clave);
                if($validacion->estado == 1)
                {
                    $empleado = empleado::TraerUnempleadoPorMail($email);
                    $datos= $validacion->empleado; //array('perfil'=>$empleado->perfil);
                    $token= AutentificadorJWT::CrearToken($datos);
                    //$retorno=array('msj'=> $validacion->msj, 'token'=>$token );
                    $retorno=array('token' => $token, 'msj'=> $validacion->msj, 'Empleado'=>$validacion->empleado );
                    return $response->withJson($retorno ,200);
                }
                else
                {
                    return $validacion->msj;
                    //$newResponse = $response->withJson( $retorno ,409); 
                }
        }
        else
        {
                return "Faltan los datos del empleado y su clave" ;
        }
    }
    
//     public static function verificarToken(Request $request, Response $response) 
//     { 
//    // $app->get('/tomarToken[/]', function (Request $request, Response $response) {    

//         $arrayConToken = $request->getHeader('miTokenUTNFRA');
//         $token=$arrayConToken[0];
    
//         try {
    
//           AutentificadorJWT::VerificarToken($token);
//           $response->getBody()->write(" PHP :Su token es ".$token);  
//           $respuesta=empleado::Traertodos();    
//           $newResponse = $response->withJson($respuesta); 
    
//         } catch (Exception $e) {
    
//           $textoError="error ".$e->getMessage();
//           $error = array('tipo' => 'acceso','descripcion' => $textoError);
//           $newResponse = $response->withJson( $error , 403); 
//         }
        
//         return $newResponse;
//     }

//$passHash = password_hash($pass, PASSWORD_BCRYPT);
                //password_verify($pass, $passHash)
    
    
    
}