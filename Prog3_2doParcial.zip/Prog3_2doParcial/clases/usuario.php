<?php
class usuario
{
	public $id;
 	public $nombre;
  	public $email;
    public $edad;
    public $perfil;
	public $clave;




//TRAER USUARIOS
public static function TraerTodosLosUsuarios()
{
	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	$consulta =$objetoAccesoDato->RetornarConsulta("select * from Usuarios");
	$consulta->execute();			
	return $consulta->fetchAll(PDO::FETCH_CLASS, "usuario");		
}

public static function TraerUnUsuario($id) 
{
	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	$consulta =$objetoAccesoDato->RetornarConsulta("select id, nombre, email, edad, perfil, clave from usuarios where id = $id");
	$consulta->execute();
	$usuarioBuscado= $consulta->fetchObject('usuario');
	return $usuarioBuscado;				
}

public static function TraerUnUsuarioPorMail($email) 
{
	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	$consulta =$objetoAccesoDato->RetornarConsulta("select id, nombre, email, edad, perfil, clave from usuarios where email = '$email'");
	$consulta->execute();
	$usuarioBuscado= $consulta->fetchObject('usuario');
	return $usuarioBuscado;				
}





//INSERTAR MODIFICAR
	public function GuardarUsuario()
	{
		if($this->id>0)
			{
				$this->ModificarUsuarioParametros();
			}else {
				$this->InsertarElUsuarioParametros();
			}
	}



//INSERTAR
	public function InsertarElUsuarioParametros()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("INSERT into usuarios  (nombre,email,edad,perfil,clave) values(:nombre,:email,:edad,:perfil,:clave)");
		$consulta->bindValue(':nombre',$this->nombre, PDO::PARAM_STR);
		$consulta->bindValue(':email', $this->email, PDO::PARAM_STR);
		$consulta->bindValue(':edad', $this->edad, PDO::PARAM_INT);
		$consulta->bindValue(':perfil', $this->perfil, PDO::PARAM_STR);
		$passHash = password_hash($this->clave, PASSWORD_BCRYPT);
		$consulta->bindValue(':clave', $passHash, PDO::PARAM_STR);
		$consulta->execute();		
		return $objetoAccesoDato->RetornarUltimoIdInsertado();
	}

	public function InsertarElUsuario()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("INSERT into usuarios (nombre,email,edad,perfil,clave)values('$this->nombre','$this->email','$this->edad','$this->perfil','$this->clave')");
		$consulta->execute();
		return $objetoAccesoDato->RetornarUltimoIdInsertado();
	}




//MODIFICAR
	public function ModificarUsuarioParametros()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();

		$consulta =$objetoAccesoDato->RetornarConsulta("
			update usuarios 
			set nombre=:nombre,
			edad=:edad,
			perfil=:perfil,
			clave=:clave
			WHERE email=:email");
		//$consulta->bindValue(':id',$this->id, PDO::PARAM_INT);
		$consulta->bindValue(':nombre',$this->nombre, PDO::PARAM_STR);
		$consulta->bindValue(':edad', $this->edad, PDO::PARAM_INT);
		$consulta->bindValue(':email', $this->email, PDO::PARAM_STR);
		$consulta->bindValue(':perfil', $this->perfil, PDO::PARAM_STR);
		$passHash = password_hash($this->clave, PASSWORD_BCRYPT);
		$consulta->bindValue(':clave', $passHash, PDO::PARAM_STR);
		return $consulta->execute();
	}

	public function ModificarUsuario()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("
			update usuarios 
			set nombre='$this->nombre',
			email='$this->email',
			edad='$this->edad'
			perfil='$this->perfil'
			WHERE id='$this->id'");
		return $consulta->execute();
	}




//BORRAR
  	public function BorrarUsuario()
	 {
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("
			delete 
			from usuarios 				
			WHERE id=:id");	
		$consulta->bindValue(':id',$this->id, PDO::PARAM_INT);		
		$consulta->execute();
		return $consulta->rowCount();
	 }

	public static function BorrarUsuarioPorEmail($email)
	 {
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("
			delete 
			from usuarios 				
			WHERE email=:email");	
		$consulta->bindValue(':email',$email, PDO::PARAM_STR);		
		$consulta->execute();
		return $consulta->rowCount();
     }
     
		 



//VERIFICAR USUARIO EMAIL/ CLAVE
	public static function verificarUsuarioPorMail($email)
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
		$resp = new stdClass();
		$consulta =$objetoAccesoDato->RetornarConsulta("select * from usuarios where email = '$email'");
		$consulta->execute();
		$usuario= $consulta->fetchObject('usuario');
		return $usuario;
	}

	public static function esValido($email, $clave) 
	{
		$usuario= $this->verificarUsuarioPorMail($email);
		if($usuario != NULL)
		{
			$verify = password_verify($clave, $usuario->clave);
			if($verify)
			{
				$resp->usuario = $usuario;
				$resp->msj = "Bienvenido ". $usuario->nombre . "!";
				$resp->perfil = $usuario->perfil;
				$resp->estado = 1;
			}
			else
			{
				$resp->msj = "Password incorrecta";
				$resp->estado = 0;
			}
		}
		else
		{
			$resp->msj = "Email no registrado";
			$resp->estado = 0;
		}
		
		return $resp;		
	}

	

	public function mostrarDatos()
	{
	  	return "Metodo mostrar:".$this->nombre."  ".$this->email."  ".$this->edad."  ".$this->perfil."  ".$this->clave;
	}

}