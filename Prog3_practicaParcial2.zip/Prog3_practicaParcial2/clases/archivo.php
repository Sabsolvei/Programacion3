<?php 
	//require_once ("Producto.php");


class Archivo {

        public static function moveUploadedFile($uploadedFile, $titulo)
        {
            //mkdir('uploads/');
            $titulo = str_replace(" ", "_", $titulo);
            $extension = pathinfo($uploadedFile->getClientFilename(), PATHINFO_EXTENSION);
            $filename = trim($titulo) .'.'. $extension;

            $ruta = 'uploads/' . $filename;
            $uploadedFile->moveTo($ruta);
        
            return $ruta;
        }

        public static function moverFotoABackup($pathviejo, $titulo)
        {
            //mkdir("ProductosBorrados/");
            $extension = pathinfo($pathviejo, PATHINFO_EXTENSION);
            rename($pathviejo , "./ProductosBorrados/".trim($titulo)."-".date("Ymd_His").".".$extension);
        }
    }
 
?>