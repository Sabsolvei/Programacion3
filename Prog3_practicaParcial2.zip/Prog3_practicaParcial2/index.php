<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once './composer/vendor/autoload.php';
require_once './clases/AccesoDatos.php';
require_once './clases/usuariosApi.php';
require_once './clases/comentarioApi.php';
require_once './clases/loginApi.php';
require_once './clases/MWparaAutentificar.php';
require_once './clases/MWparaCors.php';
require_once './clases/AutentificadorJWT.php';

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new \Slim\App(["settings" => $config]);



$app->post('/ingreso/', \loginApi::class . ':login');


/*LLAMADA A METODOS DE INSTANCIA DE UNA CLASE*/
$app->group('/usuario', function () {   

  $this->get('/', \usuarioApi::class . ':traerTodos');
  $this->get('/{id}', \usuarioApi::class . ':traerUno');//->name('traerUsuario');
  $this->delete('/', \usuarioApi::class . ':BorrarUno');//->redirect($app->urlFor('traerUsuario'));
  $this->put('/', \usuarioApi::class . ':ModificarUno');
  $this->post('/', \usuarioApi::class . ':CargarUno');

});//->add(\MWparaAutentificar::class . ':VerificarUsuario');

$app->group('/comentario', function () {   
  
    $this->get('/', \comentarioApi::class . ':traerTodos');
    $this->get('/traermail/{email}', \comentarioApi::class . ':traerUno');
    $this->delete('/', \comentarioApi::class . ':BorrarUno');
    $this->put('/', \comentarioApi::class . ':ModificarUno');
    $this->post('/', \comentarioApi::class . ':CargarUno');
    $this->get('/grilla[/{email}[/{titulo}]]', \comentarioApi::class . ':generarTabla');//->add(\MWparaCors::class . ':HabilitarCORS4200');

  });//->add(\MWparaAutentificar::class . ':VerificarUsuario');


$app->run();

// $_SERVER["REMOTE_ADDR"];