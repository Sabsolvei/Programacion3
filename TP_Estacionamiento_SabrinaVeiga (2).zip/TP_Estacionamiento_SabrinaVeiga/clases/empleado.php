<?php
class empleado
{
	public $id;
	public $nombre;
	public $apellido;
	public $email;
	public $clave;
	public $turno;
	public $perfil;
	public $fechaCreacion;
	public $foto;
	public $estado;


//TRAER empleadoS
public static function TraerTodosLosEmpleados()
{
	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	$consulta =$objetoAccesoDato->RetornarConsulta("select * from empleados");
	$consulta->execute();			
	return $consulta->fetchAll(PDO::FETCH_CLASS, "empleado");		
}

public static function TraerUnEmpleado($id) 
{
	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	$consulta =$objetoAccesoDato->RetornarConsulta("select id, nombre, apellido, email, turno, perfil, fechaCreacion, foto, estado from empleados where id = $id");
	$consulta->execute();
	$empleadoBuscado= $consulta->fetchObject('empleado');
	return $empleadoBuscado;				
}

public static function TraerUnEmpleadoPorMail($email) 
{
	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	$consulta =$objetoAccesoDato->RetornarConsulta("select id, nombre, apellido, email, clave, turno, perfil, fechaCreacion, foto, estado from empleados where email = '$email'");
	$consulta->execute();
	$empleadoBuscado= $consulta->fetchObject('empleado');
	return $empleadoBuscado;				
}

public static function TraerListadoEmpleados() 
{
	//VER QUERY!!!!!!!!!
	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	$consulta =$objetoAccesoDato->RetornarConsulta("SELECT em.id, em.nombre, (Count(es.idEmpleadoEntrada))+(Count(es.idEmpleadoSalida)) as cantidadOperaciones
													FROM empleados em
													inner join estacionamiento es on em.Id = es.IdEmpleadoEntrada");
	$consulta->execute();
	$empleadoBuscado= $consulta->fetchObject('empleado');
	return $empleadoBuscado;				
}


//INSERTAR MODIFICAR
	public function GuardarEmpleado()
	{
		if($this->id>0)
			{
				$this->ModificarempleadoParametros();
			}else {
				$this->InsertarElempleadoParametros();
			}
	}

	public function InsertarLoginDeEmpleado($fechaLogin)
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("INSERT into ingresosempleados (fecha_Hora_Ingreso, id_Empleado) values(:fechaHoraIngreso, :idEmpleado)");
		$consulta->bindValue(':fechaHoraIngreso',$fechaLogin, PDO::PARAM_STR);
		$consulta->bindValue(':idEmpleado',$this->id, PDO::PARAM_STR);
		
		$consulta->execute();		
		return $objetoAccesoDato->RetornarUltimoIdInsertado();
	}



//INSERTAR
	public function InsertarElEmpleadoParametros()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("INSERT into empleados  (nombre, apellido, email, clave, turno, perfil, fechaCreacion, foto, estado) values(:nombre,:apellido,:email,:clave,:turno,:perfil,:fechaCreacion,:foto,:estado)");
		$consulta->bindValue(':nombre',$this->nombre, PDO::PARAM_STR);
		$consulta->bindValue(':apellido',$this->apellido, PDO::PARAM_STR);
		$consulta->bindValue(':email', $this->email, PDO::PARAM_STR);
		//$passHash = password_hash($this->clave, PASSWORD_BCRYPT);
		$consulta->bindValue(':clave', $this->clave, PDO::PARAM_STR);
		$consulta->bindValue(':turno', $this->turno, PDO::PARAM_STR);
		$consulta->bindValue(':perfil', $this->perfil, PDO::PARAM_STR);
		$consulta->bindValue(':fechaCreacion', $this->fechaCreacion, PDO::PARAM_STR);
		$consulta->bindValue(':foto', $this->foto, PDO::PARAM_STR);
		$consulta->bindValue(':estado', $this->estado, PDO::PARAM_STR);
		
		$consulta->execute();		
		return $objetoAccesoDato->RetornarUltimoIdInsertado();
	}



//MODIFICAR
	public function ModificarEmpleadoParametros()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();

		$consulta =$objetoAccesoDato->RetornarConsulta("
			update empleados 
			set nombre=:nombre,
			apellido=:apellido,
			clave=:clave,
			turno=:turno,
			perfil=:perfil,
			
			estado=:estado,
			email=:email
			WHERE id=:id");
			$consulta->bindValue(':nombre',$this->nombre, PDO::PARAM_STR);
			$consulta->bindValue(':apellido',$this->apellido, PDO::PARAM_STR);
			$consulta->bindValue(':email', $this->email, PDO::PARAM_STR);
	
			$passHash = password_hash($this->clave, PASSWORD_BCRYPT);
			$consulta->bindValue(':clave', $passHash, PDO::PARAM_STR);
	
			$consulta->bindValue(':turno', $this->turno, PDO::PARAM_STR);
			$consulta->bindValue(':perfil', $this->perfil, PDO::PARAM_STR);
			$consulta->bindValue(':id', $this->id, PDO::PARAM_INT);
			//$consulta->bindValue(':foto', $this->foto, PDO::PARAM_STR);
			$consulta->bindValue(':estado', $this->estado, PDO::PARAM_STR);
		return $consulta->execute();
	}




//BORRAR
  	public function BorrarEmpleado()
	 {
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("
			delete 
			from empleados 				
			WHERE id=:id");	
		$consulta->bindValue(':id',$this->id, PDO::PARAM_INT);		
		$consulta->execute();
		return $consulta->rowCount();
	 }

	public static function BorrarEmpleadoPorEmail($email)
	 {
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("
			delete 
			from empleados 				
			WHERE email=:email");	
		$consulta->bindValue(':email',$email, PDO::PARAM_STR);		
		$consulta->execute();
		return $consulta->rowCount();
     }
     
		 



//VERIFICAR empleado EMAIL/ CLAVE
	// public static function VerificarEmpleadoPorMail($email)
	// {
	// 	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
	// 	$resp = new stdClass();
	// 	$consulta =$objetoAccesoDato->RetornarConsulta("select * from empleados where email = '$email'");
	// 	$consulta->execute();
	// 	$empleado= $consulta->fetchObject('empleado');
	// 	return $empleado;
	// }

	public static function esValido($email, $clave) 
	{
		$resp = new stdClass();
		$empleado= empleado::TraerUnEmpleadoPorMail($email);
		if($empleado != NULL)
		{
			$verify = password_verify($clave, $empleado->clave);
			if($verify)
			{
				$resp->empleado = $empleado;
				$resp->msj = "Bienvenido ". $empleado->nombre . "!";
				$resp->perfil = $empleado->perfil;
				$resp->estado = 1;
			}
			else
			{
				$resp->msj = "Password incorrecta";
				$resp->estado = 0;
			}
		}
		else
		{
			$resp->msj = "Email no registrado";
			$resp->estado = 0;
		}
		
		return $resp;		
	}

	

	public function mostrarDatos()
	{
	  	return "Metodo mostrar:".$this->nombre."  ".$this->email."  ".$this->perfil;
	}

}