<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once './clases/PHPExcel.php';
require_once './composer/vendor/autoload.php';
require_once './clases/AccesoDatos.php';
require_once './clases/empleadosApi.php';
require_once './clases/estacionamientoApi.php';
require_once './clases/loginApi.php';
require_once './clases/archivoApi.php';
require_once './clases/MWparaAutentificar.php';
require_once './clases/MWparaCors.php';
require_once './clases/AutentificadorJWT.php';

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new \Slim\App(["settings" => $config]);



$app->post('/ingreso/', \loginApi::class . ':login');


/*LLAMADA A METODOS DE INSTANCIA DE UNA CLASE*/
$app->group('/empleado', function () {   

  $this->get('/', \empleadosApi::class . ':traerTodos');
  $this->get('/empleadosLogins', \empleadosApi::class . ':traerFechasLogins');
  $this->get('/cantidadOperaciones', \empleadosApi::class . ':traerCantidadOperaciones');
  $this->get('/{id}', \empleadosApi::class . ':traerUno');//->name('traerempleado');
  $this->delete('/', \empleadosApi::class . ':BorrarUno');//->redirect($app->urlFor('traerempleado'));
  $this->put('/', \empleadosApi::class . ':ModificarUno');
  $this->post('/', \empleadosApi::class . ':CargarUno');

});//->add(\MWparaAutentificar::class . ':Verificarempleado');

$app->group('/estacionamiento', function () {   
  
    $this->get('/', \estacionamientoApi::class . ':traerTodos');
    $this->get('/datosEstacionados', \estacionamientoApi::class . ':traerDatosEstacionados');
    $this->get('/cocheraMasUtilizada', \estacionamientoApi::class . ':traerCocheraMasUsada');
    $this->get('/cocheraMenosUtilizada', \estacionamientoApi::class . ':traerCocheraMenosUsada');
    $this->get('/cocherasNoUtilizadas', \estacionamientoApi::class . ':traerCocherasNoUsadas');
    $this->get('/traermail/{email}', \estacionamientoApi::class . ':traerUno');
    $this->delete('/', \estacionamientoApi::class . ':BorrarUno');
    $this->put('/', \estacionamientoApi::class . ':ModificarUno');
    $this->post('/', \estacionamientoApi::class . ':CargarUno');
    $this->get('/grilla[/{email}[/{titulo}]]', \estacionamientoApi::class . ':generarTabla');//->add(\MWparaCors::class . ':HabilitarCORS4200');

  });//->add(\MWparaAutentificar::class . ':Verificarempleado');


  $app->group('/archivos', function () {   
    
      $this->get('/excelEstacionados', \archivoApi::class . ':exportarExcelEstacionados');
      $this->get('/pdfEstacionados', \archivoApi::class . ':exportarPDFEstacionados');

    });

$app->run();

// $_SERVER["REMOTE_ADDR"];