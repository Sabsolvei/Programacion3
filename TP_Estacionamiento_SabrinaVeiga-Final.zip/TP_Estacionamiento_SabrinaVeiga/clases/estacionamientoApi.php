<?php
require_once 'estacionamiento.php';
require_once 'archivo.php';
require_once 'empleado.php';
//require_once 'IApiUsable.php';

class estacionamientoApi extends estacionamiento //implements IApiUsable
{

    public function TraerUno($request, $response, $args)
    {
            $patente = $args['patente'];
            $estacionamientos=estacionamiento::TraerEstacionamientoPorPatente($patente);
            $newResponse = $response->withJson($estacionamientos, 200);
            return $newResponse;
    }
    
    public function traerTodos($request, $response, $args)
    {
            $todosLosestacionamientos=estacionamiento::TraerTodosLosEstacionamientos();
            $response = $response->withJson($todosLosestacionamientos, 200);
            return $response;
    }

    public function traerDatosEstacionados($request, $response, $args)
    {
            $todosLosEstacionados=estacionamiento::TraerDatosEstacionamiento();
            //Archivo::exportarExcel($todosLosEstacionados);
            $response = $response->withJson($todosLosEstacionados, 200);
            return $response;
    }


    //TRAER COCHERAS  MAS/MENOS/NO  UTILIZADAS

    public function traerCocheraMasUsada($request, $response, $args)
    {
            $todosLosestacionamientos=estacionamiento::traerCocheraMasUtilizada();
            $response = $response->withJson($todosLosestacionamientos, 200);
            return $response;
    }
    public function traerCocheraMenosUsada($request, $response, $args)
    {
            $todosLosestacionamientos=estacionamiento::traerCocheraMenosUtilizada();
            $response = $response->withJson($todosLosestacionamientos, 200);
            return $response;
    }
    public function traerCocherasNoUsadas($request, $response, $args)
    {
            $todosLosestacionamientos=estacionamiento::TraerCocherasNoUtilizadas();
            $response = $response->withJson($todosLosestacionamientos, 200);
            return $response;
    }




    public function CargarUno($request, $response, $args)
    {
        $ArrayDeParametros = $request->getParsedBody();
        if (isset($ArrayDeParametros['discapacitado']) && isset($ArrayDeParametros['patente']) && isset($ArrayDeParametros['color'])) 
        {
            $cochera = estacionamiento::TraerCochera($ArrayDeParametros['discapacitado']);
            if (!is_null($cochera)) {
                $patente = $ArrayDeParametros['patente'];
                $estacionado = estacionamiento::TraerEstacionamientoOcupadoPorPatente($patente);
                if (empty($estacionado)) {
                    $idCochera = $cochera[0][0];
                    $color = $ArrayDeParametros['color'];
                    $arrayConToken = $request->getHeader('token');
                    $token=$arrayConToken[0];
                    $data = AutentificadorJWT::ObtenerData($token);
                    $idEmpleadoEntrada = $data->id;
                    $fechaHoraIngreso = date("Y/m/d H:i:s");
            
                    $miEstacionamiento = new estacionamiento();
                    $miEstacionamiento->idCochera=$idCochera;
                    $miEstacionamiento->patente=$patente;
                    $miEstacionamiento->color=$color;
                    $miEstacionamiento->idEmpleadoEntrada=$idEmpleadoEntrada;
                    $miEstacionamiento->fechaHoraIngreso=$fechaHoraIngreso;
            
                    $ruta = $this->obtenerArchivo($request, $response, $patente);
                    if (!is_null($ruta) && $ruta!=false) {
                        $miEstacionamiento->foto = $ruta;
                        $miEstacionamiento->InsertarElEstacionamientoParametros();
                        $miEstacionamiento->OcuparCochera();
                        $response->getBody()->write("El vehiculo fue guardado.");
                    } else {
                        $response->getBody()->write("Error al intentar guardar la foto.");
                    }
                } else {
                    $response->getBody()->write("El vehículo con la patente ingresada ya esta dentro del estacionamiento.");
                }
            } else {
                $response->getBody()->write("No hay cocheras disponibles.");
            }
        } else {
            $response->getBody()->write("No se ingresaron todos los parametros obligatorios.");
        }

        return $response;
    }



    public function obtenerArchivo($request, $response, $patente)
    {
        $uploadedFiles = $request->getUploadedFiles();
        if (isset($uploadedFiles['archivo'])) {
            $uploadedFile = $uploadedFiles['archivo'];
            if ($uploadedFile->getError() === UPLOAD_ERR_OK) {
                $ruta = archivo::moveUploadedFile($uploadedFile, $patente, 'fotosVehiculos/');
                return $ruta;
            } else {
                return null;
            }
        } else {
            return false;
        }
    }
    
     
    public function ModificarUno($request, $response, $args)
    {
            $objDelaRespuesta= new stdclass();
            $estacionamientoAModificar = new estacionamiento();
            $ArrayDeParametros = $request->getParsedBody();

        if (isset($ArrayDeParametros['patente'])) {
            $estacionamientoAModificar = $estacionamientoAModificar->TraerCocheEstacionadoPorPatente($ArrayDeParametros['patente']);
            
            if (!empty($estacionamientoAModificar)) {
                $estacionadoQueEgresa = $estacionamientoAModificar[0];
                $estacionadoQueEgresa->DesocuparCochera();
                $data = AutentificadorJWT::ObtenerData($request->getHeader('token')[0]);
                $estacionadoQueEgresa->idEmpleadoSalida = $data->id;
                $estacionadoQueEgresa->fechaHoraEgreso = date("Y/m/d H:i:s");

                $estacionadoQueEgresa->CalcularImporte();

                $estacionadoQueEgresa->ModificarEstacionamiento();
                $objDelaRespuesta->estacionado = $estacionadoQueEgresa;
                $objDelaRespuesta->resultado= "El vehiculo fue despachado con exito.";
            } else {
                $objDelaRespuesta->resultado= "La patente ingresada no existe.";
            }
        } else {
            $objDelaRespuesta->resultado= "Debe ingresar la patente.";
        }

        return $response->withJson($objDelaRespuesta, 200);
    }
    


    public function BorrarUno($request, $response, $args)
    {
            $ArrayDeParametros = $request->getParsedBody(); //form-urlencoded
            $patente = $ArrayDeParametros['patente'];

            $estacionamiento = new estacionamiento();
            $estacionamiento->patente = $patente;
            $cantidadDeBorrados = $estacionamiento->BorrarEstacionamiento();

            $objDelaRespuesta = new stdclass();
            
        if ($cantidadDeBorrados > 0) {
            $objDelaRespuesta->cantidad = $cantidadDeBorrados;
            $objDelaRespuesta->resultado = "El Comentario con patente: ".$patente." fue eliminado exitosamente";
        } else {
            $objDelaRespuesta->resultado = "No Borro nada!!!";
        }
            $newResponse = $response->withJson($objDelaRespuesta, 200);
            return $newResponse;
    }
}
