<?php
require_once 'empleado.php';
require_once 'archivo.php';

class loginApi//extends login
{
    public function login($request, $response, $args) 
    {
        $token="";
        $ArrayDeParametros = $request->getParsedBody();
        $objDelaRespuesta= new stdclass();
        if(isset( $ArrayDeParametros['email']) && isset( $ArrayDeParametros['clave']) )
        {
                $email=$ArrayDeParametros['email'];
                $clave= $ArrayDeParametros['clave'];
                $rtaEsValido = empleado::esValido($email,$clave);

                if($rtaEsValido->estado == 1)
                {
                    $empleado= $rtaEsValido->empleado;
                    $objDelaRespuesta->token = AutentificadorJWT::CrearToken($empleado);
                    $objDelaRespuesta->mensaje = $rtaEsValido->msj;
                    $empleado->InsertarLoginDeEmpleado(date("Y/m/d H:i:s"));
                    return $response->withJson($objDelaRespuesta ,200);
                }
                else
                {
                    $objDelaRespuesta->acceso = $rtaEsValido->msj;
                    return $response->withJson($objDelaRespuesta, 409);
                }
        }
        else
        {
            $objDelaRespuesta->error = "Debe completar los campos email y clave";
            return $response->withJson($objDelaRespuesta, 409);
        }
    } 
}