define ({
    "name": "Estacionamiento 2017",
    "version": "0.1.0",
    "description": "Api TPFinal",
    "title": "API REST Estacionamiento",
    "url": "http://localhost/PROGRAMACION3/Prog3_TP-Estacionamiento_Final/TP_Estacionamiento_SabrinaVeiga/"
});