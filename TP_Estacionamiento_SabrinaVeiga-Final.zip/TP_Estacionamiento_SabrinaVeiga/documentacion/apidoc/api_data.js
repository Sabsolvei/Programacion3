define({ "api": [
  {
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "varname1",
            "description": "<p>No type.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "varname2",
            "description": "<p>With type.</p>"
          }
        ]
      }
    },
    "type": "",
    "url": "",
    "version": "0.0.0",
    "filename": "TP_Estacionamiento_SabrinaVeiga/doc/main.js",
    "group": "C__xampp_htdocs_PROGRAMACION3_Prog3_TP_Estacionamiento_Final_TP_Estacionamiento_SabrinaVeiga_doc_main_js",
    "groupTitle": "C__xampp_htdocs_PROGRAMACION3_Prog3_TP_Estacionamiento_Final_TP_Estacionamiento_SabrinaVeiga_doc_main_js",
    "name": ""
  },
  {
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "varname1",
            "description": "<p>No type.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "varname2",
            "description": "<p>With type.</p>"
          }
        ]
      }
    },
    "type": "",
    "url": "",
    "version": "0.0.0",
    "filename": "TP_Estacionamiento_SabrinaVeiga/documentacion/apidoc/main.js",
    "group": "C__xampp_htdocs_PROGRAMACION3_Prog3_TP_Estacionamiento_Final_TP_Estacionamiento_SabrinaVeiga_documentacion_apidoc_main_js",
    "groupTitle": "C__xampp_htdocs_PROGRAMACION3_Prog3_TP_Estacionamiento_Final_TP_Estacionamiento_SabrinaVeiga_documentacion_apidoc_main_js",
    "name": ""
  },
  {
    "type": "post",
    "url": "/estacionamiento",
    "title": "Ingresar vehiculo al Estacionamiento",
    "group": "ESTACIONAMIENTO",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "patente",
            "description": "<p>estacionamiento patente</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "color",
            "description": "<p>estacionamiento color</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "discapacitado",
            "description": "<p>estacionamiento discapacitado</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "archivo",
            "description": "<p>estacionamiento foto del auto</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Campos obligatorios",
          "content": "{\n  \"patente\": \"AA123BB\",\n  \"color\": \"blanco\",\n  \"discapacitado\": true,\n  \"archivo\": \"fotosVehiculo/AA123BB.jpg\"\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "patente",
            "description": "<p>estacionamiento patente</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "color",
            "description": "<p>estacionamiento color</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "discapacitado",
            "description": "<p>estacionamiento discapacitado</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "archivo",
            "description": "<p>estacionamiento Foto del auto jpg png</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success",
          "content": "HTTP/1.1 200 OK\n\"El vehiculo fue guardado.\"",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Register error",
          "content": "HTTP/1.1 500 Internal Server Error",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "TP_Estacionamiento_SabrinaVeiga/index.php",
    "groupTitle": "ESTACIONAMIENTO",
    "name": "PostEstacionamiento"
  },
  {
    "type": "put",
    "url": "/estacionamiento",
    "title": "Sacar vehiculo del Estacionamiento",
    "group": "ESTACIONAMIENTO",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "id",
            "optional": false,
            "field": "patente",
            "description": "<p>estacionamiento patente</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Input",
          "content": "{\n  \"patente\": \"AA432MM\"\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success",
          "content": "  {\n    \"estacionado\": {\n     \"id\": 10,\n     \"patente\": \"AA432MM\",\n     \"color\": \"negro\",\n     \"foto\": \"fotosVehiculos/AA432MM.jpg\",\n     \"idEmpleadoEntrada\": 2,\n     \"fechaHoraIngreso\": \"2017/12/05 19:56:32\",\n     \"idEmpleadoSalida\": 2,\n     \"fechaHoraEgreso\": \"2017/12/05 20:35:44\",\n     \"tiempoTranscurrido\": \"0 DIAS | 0 HS\",\n     \"importe\": 0,\n     \"idCochera\": \"1F\"\n      },\n  \"resultado\": \"El vehiculo fue despachado con exito.\"\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Update error",
          "content": "HTTP/1.1 500 Internal Server Error",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "TP_Estacionamiento_SabrinaVeiga/index.php",
    "groupTitle": "ESTACIONAMIENTO",
    "name": "PutEstacionamiento"
  },
  {
    "type": "delete",
    "url": "/empleado",
    "title": "Eliminar un empleado",
    "group": "Empleado",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "id",
            "optional": false,
            "field": "id",
            "description": "<p>empleado id</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Input",
          "content": "{\n  \"id\": 1\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success",
          "content": "{\n   \"resultado\": \"El empleado con id: 1 fue eliminado exitosamente\"\n }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Delete error",
          "content": "HTTP/1.1 500 Internal Server Error",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "TP_Estacionamiento_SabrinaVeiga/index.php",
    "groupTitle": "Empleado",
    "name": "DeleteEmpleado"
  },
  {
    "type": "get",
    "url": "/empleado",
    "title": "Lista todos los empleados",
    "group": "Empleado",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "lista",
            "description": "<p>de empleados</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "empleado.nombre",
            "description": "<p>Empleado nombre</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "empleado.apellido",
            "description": "<p>Empleado apellido</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "empleado.estado",
            "description": "<p>Empleado estado</p>"
          },
          {
            "group": "Success 200",
            "type": "Date",
            "optional": false,
            "field": "empleado.fechacreacion",
            "description": "<p>Fecha de creacion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success",
          "content": "HTTP/1.1 200 OK\n[{\n  \"id\": 1,\n  \"nombre\": \"Juan\",\n  \"apellido\": \"Perez\",\n  \"email\": \"juanperez87@gmail.com\",\n  \"clave\": \"$2y$10$TQkVupeMO/giBJHwd8evquV3tqK6OOge/miLIxU.4a5UENA6ydz7G\",\n  \"turno\": \"Manana\",\n  \"perfil\": \"user\",\n  \"fechaCreacion\": \"2017/11/26 20:26:16\",\n  \"foto\": null,\n  \"estado\": \"Activo\"\n}]",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "List error",
          "content": "HTTP/1.1 500 Internal Server Error",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "TP_Estacionamiento_SabrinaVeiga/index.php",
    "groupTitle": "Empleado",
    "name": "GetEmpleado"
  },
  {
    "type": "get",
    "url": "/empleado",
    "title": "Trae un empleado",
    "group": "Empleado",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "id",
            "optional": false,
            "field": "id",
            "description": "<p>empleado id</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "lista",
            "description": "<p>de empleados</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "empleado.nombre",
            "description": "<p>Empleado nombre</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "empleado.apellido",
            "description": "<p>Empleado apellido</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "empleado.estado",
            "description": "<p>Empleado estado</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "empleado.fechacreacion",
            "description": "<p>Fecha de creacion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success",
          "content": "HTTP/1.1 200 OK\n[{\n  \"id\": 1,\n  \"nombre\": \"Juan\",\n  \"apellido\": \"Perez\",\n  \"email\": \"juanperez87@gmail.com\",\n  \"clave\": \"$2y$10$TQkVupeMO/giBJHwd8evquV3tqK6OOge/miLIxU.4a5UENA6ydz7G\",\n  \"turno\": \"Manana\",\n  \"perfil\": \"user\",\n  \"fechaCreacion\": \"2017/11/26 20:26:16\",\n  \"foto\": null,\n  \"estado\": \"Activo\"\n}]",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "List error",
          "content": "HTTP/1.1 500 Internal Server Error",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "TP_Estacionamiento_SabrinaVeiga/index.php",
    "groupTitle": "Empleado",
    "name": "GetEmpleado"
  },
  {
    "type": "post",
    "url": "/empleado",
    "title": "Registrar nuevo empleado",
    "group": "Empleado",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "nombre",
            "description": "<p>empleado nombre</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "apellido",
            "description": "<p>empleado apellido</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>empleado email</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "clave",
            "description": "<p>empleado clave</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "turno",
            "description": "<p>Manana / Tarde / Noche</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "estado",
            "description": "<p>Activo / Inactivo / Suspendido</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "perfil",
            "description": "<p>Admin / User</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "foto",
            "description": "<p>jpg / png</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Campos obligatorios",
          "content": "{\n  \"nombre\": \"Juan\",\n  \"apellido\": \"Perez\",\n  \"email\": \"juanperez87@gmail.com\",\n  \"clave\": \"1234\",\n  \"turno\": \"Manana\"\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "empleado.nombre",
            "description": "<p>Empleado nombre</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "empleado.apellido",
            "description": "<p>Empleado apellido</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "empleado.email",
            "description": "<p>Empleado email</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "clave",
            "description": "<p>empleado clave</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "turno",
            "description": "<p>Manana, Tarde o Noche</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "estado",
            "description": "<p>Activo por default</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "perfil",
            "description": "<p>User por default</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "foto",
            "description": "<p>null por default</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success",
          "content": "HTTP/1.1 200 OK\n\"Se guardo el empleado\"",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Register error",
          "content": "HTTP/1.1 500 Internal Server Error",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "TP_Estacionamiento_SabrinaVeiga/index.php",
    "groupTitle": "Empleado",
    "name": "PostEmpleado"
  },
  {
    "type": "put",
    "url": "/empleado",
    "title": "Actualizar estado del empleado",
    "group": "Empleado",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "id",
            "optional": false,
            "field": "id",
            "description": "<p>empleado id</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "estado",
            "description": "<p>empleado estado</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Input",
          "content": "{\n  \"id\": 1,\n  \"estado\": \"Inactivo\"\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success",
          "content": "{\n  \"resultado\": true,\n  \"msj\": \"Empleado modificado con exito\"\n }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Update error",
          "content": "HTTP/1.1 500 Internal Server Error",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "TP_Estacionamiento_SabrinaVeiga/index.php",
    "groupTitle": "Empleado",
    "name": "PutEmpleado"
  },
  {
    "type": "post",
    "url": "/ingreso",
    "title": "Login de usuario",
    "group": "Login",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>empleado email</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "clave",
            "description": "<p>empleado clave</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Campos obligatorios",
          "content": "{\n  \"email\": \"juanperez87@gmail.com\",\n  \"clave\": \"1234\"\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "token",
            "description": "<p>Genera token</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success",
          "content": "HTTP/1.1 200 OK\n{\n    \"token\": \"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE1MTI0ODc4MjEsImV4cCI6MTUxMjY2MDYyMSwiYXVkIjoiNWI1ZDFiMjQ5MjgwNjJkZDMyMjJlM2FlODM1ODMwM2MwY2NhMzFiOSIsImRhdGEiOnsiaWQiOjUsIm5vbWJyZSI6Ik1hcmlhbm8iLCJhcGVsbGlkbyI6IlJvZHJpcXVleiIsImVtYWlsIjoibWFyaWFub3JvZHJpZ3VlekBnbWFpbC5jb20iLCJjbGF2ZSI6IiQyeSQxMCRycWtMSlwvbzNieDdyQjN6YnpBbjI2ZUt5WUN5S2h0ZElwZFYuWDRYS0txNlp6RmM2WTVFM2EiLCJ0dXJubyI6IlRhcmRlIiwicGVyZmlsIjoidXNlciIsImZlY2hhQ3JlYWNpb24iOiIyMDE3XC8xMlwvMDMgMjE6MTU6MTUiLCJmb3RvIjoiZm90b3NFbXBsZWFkb3NcL21hcmlhbm9yb2RyaWd1ZXpAZ21haWwuY29tLmpwZyIsImVzdGFkbyI6IkFjdGl2byJ9LCJhcHAiOiJBUEkgUkVTVCBDRCAyMDE3In0.P1rxyn28gAYEiedq0EjpEQ8s6yFQ3DKr7CVArF1tGWI\",\n    \"mensaje\": \"Bienvenida/o Juan!\"\n }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Register error",
          "content": "HTTP/1.1 500 Internal Server Error",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "TP_Estacionamiento_SabrinaVeiga/index.php",
    "groupTitle": "Login",
    "name": "PostIngreso"
  },
  {
    "type": "any",
    "url": "/HabilitarCORS4200/",
    "title": "HabilitarCORS4200",
    "version": "0.1.0",
    "name": "HabilitarCORS4200",
    "group": "MIDDLEWARE",
    "description": "<p>Por medio de este MiddleWare habilito que se pueda acceder desde http://localhost:4200</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "ServerRequestInterface",
            "optional": false,
            "field": "request",
            "description": "<p>El objeto REQUEST.</p>"
          },
          {
            "group": "Parameter",
            "type": "ResponseInterface",
            "optional": false,
            "field": "response",
            "description": "<p>El objeto RESPONSE.</p>"
          },
          {
            "group": "Parameter",
            "type": "Callable",
            "optional": false,
            "field": "next",
            "description": "<p>The next middleware callable.</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Como usarlo:",
        "content": "->add(\\verificador::class . ':HabilitarCORS4200')",
        "type": "json"
      }
    ],
    "filename": "TP_Estacionamiento_SabrinaVeiga/clases/MWparaCors.php",
    "groupTitle": "MIDDLEWARE"
  },
  {
    "type": "any",
    "url": "/HabilitarCORS8080/",
    "title": "HabilitarCORS8080",
    "version": "0.1.0",
    "name": "HabilitarCORS8080",
    "group": "MIDDLEWARE",
    "description": "<p>Por medio de este MiddleWare habilito que se pueda acceder desde http://localhost:8080</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "ServerRequestInterface",
            "optional": false,
            "field": "request",
            "description": "<p>El objeto REQUEST.</p>"
          },
          {
            "group": "Parameter",
            "type": "ResponseInterface",
            "optional": false,
            "field": "response",
            "description": "<p>El objeto RESPONSE.</p>"
          },
          {
            "group": "Parameter",
            "type": "Callable",
            "optional": false,
            "field": "next",
            "description": "<p>The next middleware callable.</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Como usarlo:",
        "content": "->add(\\verificador::class . ':HabilitarCORS8080')",
        "type": "json"
      }
    ],
    "filename": "TP_Estacionamiento_SabrinaVeiga/clases/MWparaCors.php",
    "groupTitle": "MIDDLEWARE"
  },
  {
    "type": "any",
    "url": "/HabilitarCORSTodos/",
    "title": "HabilitarCORSTodos",
    "version": "0.1.0",
    "name": "HabilitarCORSTodos",
    "group": "MIDDLEWARE",
    "description": "<p>Por medio de este MiddleWare habilito que se pueda acceder desde cualquier servidor</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "ServerRequestInterface",
            "optional": false,
            "field": "request",
            "description": "<p>El objeto REQUEST.</p>"
          },
          {
            "group": "Parameter",
            "type": "ResponseInterface",
            "optional": false,
            "field": "response",
            "description": "<p>El objeto RESPONSE.</p>"
          },
          {
            "group": "Parameter",
            "type": "Callable",
            "optional": false,
            "field": "next",
            "description": "<p>The next middleware callable.</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Como usarlo:",
        "content": "->add(\\verificador::class . ':HabilitarCORSTodos')",
        "type": "json"
      }
    ],
    "filename": "TP_Estacionamiento_SabrinaVeiga/clases/MWparaCors.php",
    "groupTitle": "MIDDLEWARE"
  },
  {
    "type": "any",
    "url": "/MWparaAutenticar/",
    "title": "Verificar Usuario",
    "version": "0.1.0",
    "name": "VerificarUsuario",
    "group": "MIDDLEWARE",
    "description": "<p>Por medio de este MiddleWare verifico las credeciales antes de ingresar al correspondiente metodo</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "ServerRequestInterface",
            "optional": false,
            "field": "request",
            "description": "<p>El objeto REQUEST.</p>"
          },
          {
            "group": "Parameter",
            "type": "ResponseInterface",
            "optional": false,
            "field": "response",
            "description": "<p>El objeto RESPONSE.</p>"
          },
          {
            "group": "Parameter",
            "type": "Callable",
            "optional": false,
            "field": "next",
            "description": "<p>The next middleware callable.</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Como usarlo:",
        "content": "->add(\\MWparaAutenticar::class . ':VerificarUsuario')",
        "type": "json"
      }
    ],
    "filename": "TP_Estacionamiento_SabrinaVeiga/clases/MWparaAutentificar.php",
    "groupTitle": "MIDDLEWARE"
  }
] });
