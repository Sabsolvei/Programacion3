define({
  "name": "",
  "version": "0.0.0",
  "description": "",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2017-12-05T19:40:16.463Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
