<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once './clases/PHPExcel.php';
require_once './composer/vendor/autoload.php';
require_once './clases/AccesoDatos.php';
require_once './clases/empleadosApi.php';
require_once './clases/estacionamientoApi.php';
require_once './clases/loginApi.php';
require_once './clases/archivoApi.php';
require_once './clases/MWparaAutentificar.php';
require_once './clases/MWparaCors.php';
require_once './clases/AutentificadorJWT.php';

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new \Slim\App(["settings" => $config]);


 /**
 * @api {post} /ingreso Login de usuario
 * @apiGroup Login
 * @apiParam {String} email empleado email
 * @apiParam {String} clave empleado clave

 * @apiParamExample {json} Campos obligatorios
 *    {
 *      "email": "juanperez87@gmail.com",
 *      "clave": "1234"
 *    }
 * @apiSuccess {String} token Genera token
 * @apiSuccessExample {json} Success
 *    HTTP/1.1 200 OK
 *    {
 *        "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE1MTI0ODc4MjEsImV4cCI6MTUxMjY2MDYyMSwiYXVkIjoiNWI1ZDFiMjQ5MjgwNjJkZDMyMjJlM2FlODM1ODMwM2MwY2NhMzFiOSIsImRhdGEiOnsiaWQiOjUsIm5vbWJyZSI6Ik1hcmlhbm8iLCJhcGVsbGlkbyI6IlJvZHJpcXVleiIsImVtYWlsIjoibWFyaWFub3JvZHJpZ3VlekBnbWFpbC5jb20iLCJjbGF2ZSI6IiQyeSQxMCRycWtMSlwvbzNieDdyQjN6YnpBbjI2ZUt5WUN5S2h0ZElwZFYuWDRYS0txNlp6RmM2WTVFM2EiLCJ0dXJubyI6IlRhcmRlIiwicGVyZmlsIjoidXNlciIsImZlY2hhQ3JlYWNpb24iOiIyMDE3XC8xMlwvMDMgMjE6MTU6MTUiLCJmb3RvIjoiZm90b3NFbXBsZWFkb3NcL21hcmlhbm9yb2RyaWd1ZXpAZ21haWwuY29tLmpwZyIsImVzdGFkbyI6IkFjdGl2byJ9LCJhcHAiOiJBUEkgUkVTVCBDRCAyMDE3In0.P1rxyn28gAYEiedq0EjpEQ8s6yFQ3DKr7CVArF1tGWI",
 *        "mensaje": "Bienvenida/o Juan!"
 *     }
 * @apiErrorExample {json} Register error
 *    HTTP/1.1 500 Internal Server Error
 */
$app->post('/ingreso/', \loginApi::class . ':login')->add(\MWparaCORS::class . ':HabilitarCORSTodos');


$app->group('/empleado', function () {
/**
 * @api {get} /empleado Lista todos los empleados
 * @apiGroup Empleado
 * @apiSuccess {Object[]} lista de empleados
 * @apiSuccess {String} empleado.nombre Empleado nombre
 * @apiSuccess {String} empleado.apellido Empleado apellido
 * @apiSuccess {String} empleado.estado Empleado estado
 * @apiSuccess {Date} empleado.fechacreacion Fecha de creacion
 * @apiSuccessExample {json} Success
 *    HTTP/1.1 200 OK
 *    [{
 *      "id": 1,
 *      "nombre": "Juan",
 *      "apellido": "Perez",
 *      "email": "juanperez87@gmail.com",
 *      "clave": "$2y$10$TQkVupeMO/giBJHwd8evquV3tqK6OOge/miLIxU.4a5UENA6ydz7G",
 *      "turno": "Manana",
 *      "perfil": "user",
 *      "fechaCreacion": "2017/11/26 20:26:16",
 *      "foto": null,
 *      "estado": "Activo"
 *    }]
 * @apiErrorExample {json} List error
 *    HTTP/1.1 500 Internal Server Error
 */
    $this->get('/', \empleadosApi::class . ':traerTodos');
    $this->get('/empleadosLogins', \empleadosApi::class . ':traerFechasLogins');
    $this->get('/cantidadOperaciones', \empleadosApi::class . ':traerCantidadOperaciones');

  /**
 * @api {get} /empleado Trae un empleado
 * @apiGroup Empleado
 * @apiParam {id} id empleado id
 * @apiSuccess {Object[]} lista de empleados
 * @apiSuccess {String} empleado.nombre Empleado nombre
 * @apiSuccess {String} empleado.apellido Empleado apellido
 * @apiSuccess {String} empleado.estado Empleado estado
 * @apiSuccess {String} empleado.fechacreacion Fecha de creacion
 * @apiSuccessExample {json} Success
 *    HTTP/1.1 200 OK
 *    [{
 *      "id": 1,
 *      "nombre": "Juan",
 *      "apellido": "Perez",
 *      "email": "juanperez87@gmail.com",
 *      "clave": "$2y$10$TQkVupeMO/giBJHwd8evquV3tqK6OOge/miLIxU.4a5UENA6ydz7G",
 *      "turno": "Manana",
 *      "perfil": "user",
 *      "fechaCreacion": "2017/11/26 20:26:16",
 *      "foto": null,
 *      "estado": "Activo"
 *    }]
 * @apiErrorExample {json} List error
 *    HTTP/1.1 500 Internal Server Error
 */
    $this->get('/{id}', \empleadosApi::class . ':traerUno');

 /**
 * @api {post} /empleado Registrar nuevo empleado
 * @apiGroup Empleado
 * @apiParam {String} nombre empleado nombre
 * @apiParam {String} apellido empleado apellido
 * @apiParam {String} email empleado email
 * @apiParam {String} clave empleado clave
 * @apiParam {String} turno Manana / Tarde / Noche
 * @apiParam {String} estado Activo / Inactivo / Suspendido
 * @apiParam {String} perfil Admin / User
 * @apiParam {String} foto jpg / png
 * @apiParamExample {json} Campos obligatorios
 *    {
 *      "nombre": "Juan",
 *      "apellido": "Perez",
 *      "email": "juanperez87@gmail.com",
 *      "clave": "1234",
 *      "turno": "Manana"
 *    }
 * @apiSuccess {String} empleado.nombre Empleado nombre
 * @apiSuccess {String} empleado.apellido Empleado apellido
 * @apiSuccess {String} empleado.email Empleado email
 * @apiSuccess {String} clave empleado clave
 * @apiSuccess {String} turno Manana, Tarde o Noche
 * @apiSuccess {String} estado Activo por default
 * @apiSuccess {String} perfil User por default
 * @apiSuccess {String} foto null por default
 * @apiSuccessExample {json} Success
 *    HTTP/1.1 200 OK
 *    "Se guardo el empleado"
 * @apiErrorExample {json} Register error
 *    HTTP/1.1 500 Internal Server Error
 */
    $this->post('/', \empleadosApi::class . ':CargarUno');

  /**
 * @api {put} /empleado  Actualizar estado del empleado
 * @apiGroup Empleado
 * @apiParam {id} id empleado id
 * @apiParam {String} estado empleado estado
 * @apiParamExample {json} Input
 *    {
 *      "id": 1,
 *      "estado": "Inactivo"
 *    }
 * @apiSuccessExample {json} Success
 *    {
 *      "resultado": true,
 *      "msj": "Empleado modificado con exito"
*     }
 * @apiErrorExample {json} Update error
 *    HTTP/1.1 500 Internal Server Error
 */
    $this->put('/', \empleadosApi::class . ':ModificarUno');

   /**
 * @api {delete} /empleado Eliminar un empleado
 * @apiGroup Empleado
 * @apiParam {id} id empleado id
 * @apiParamExample {json} Input
 *    {
 *      "id": 1
 *    }
 * @apiSuccessExample {json} Success
 *    {
 *       "resultado": "El empleado con id: 1 fue eliminado exitosamente"
 *     }
 * @apiErrorExample {json} Delete error
 *    HTTP/1.1 500 Internal Server Error
 */
    $this->delete('/', \empleadosApi::class . ':BorrarUno');
})->add(\MWparaAutentificar::class . ':Verificarempleado');



$app->group('/estacionamiento', function () {
  
    $this->delete('/', \estacionamientoApi::class . ':BorrarUno');

    /**
 * @api {put} /estacionamiento  Sacar vehiculo del Estacionamiento
 * @apiGroup ESTACIONAMIENTO
 * @apiParam {id} patente estacionamiento patente
 * @apiParamExample {json} Input
 *    {
 *      "patente": "AA432MM"
 *    }
 * @apiSuccessExample {json} Success
 *    {
 *      "estacionado": {
 *       "id": 10,
 *       "patente": "AA432MM",
 *       "color": "negro",
 *       "foto": "fotosVehiculos/AA432MM.jpg",
 *       "idEmpleadoEntrada": 2,
 *       "fechaHoraIngreso": "2017/12/05 19:56:32",
 *       "idEmpleadoSalida": 2,
 *       "fechaHoraEgreso": "2017/12/05 20:35:44",
 *       "tiempoTranscurrido": "0 DIAS | 0 HS",
 *       "importe": 0,
 *       "idCochera": "1F"
 *        },
 *    "resultado": "El vehiculo fue despachado con exito."
 *  }
 * @apiErrorExample {json} Update error
 *    HTTP/1.1 500 Internal Server Error
 */
    $this->put('/', \estacionamientoApi::class . ':ModificarUno');
    /**
 * @api {post} /estacionamiento  Ingresar vehiculo al Estacionamiento
 * @apiGroup ESTACIONAMIENTO
 * @apiParam {String} patente estacionamiento patente
 * @apiParam {String} color estacionamiento color
 * @apiParam {String} discapacitado estacionamiento discapacitado
 * @apiParam {String} archivo estacionamiento foto del auto
 * @apiParamExample {json} Campos obligatorios
 *    {
 *      "patente": "AA123BB",
 *      "color": "blanco",
 *      "discapacitado": true,
 *      "archivo": "fotosVehiculo/AA123BB.jpg"
 *    }
 * @apiSuccess {String} patente estacionamiento patente
 * @apiSuccess {String} color estacionamiento color
 * @apiSuccess {String} discapacitado estacionamiento discapacitado
 * @apiSuccess {String} archivo estacionamiento Foto del auto jpg png

 * @apiSuccessExample {json} Success
 *    HTTP/1.1 200 OK
 *    "El vehiculo fue guardado."
 * @apiErrorExample {json} Register error
 *    HTTP/1.1 500 Internal Server Error
 */
    $this->post('/', \estacionamientoApi::class . ':CargarUno');
});//->add(\MWparaAutentificar::class . ':Verificarempleado');



  $app->group('/reportesEstacionamiento', function () {
    
      $this->get('/', \estacionamientoApi::class . ':traerTodos');
      $this->get('/datosEstacionados', \estacionamientoApi::class . ':traerDatosEstacionados');
      $this->get('/cocheraMasUtilizada', \estacionamientoApi::class . ':traerCocheraMasUsada');
      $this->get('/cocheraMenosUtilizada', \estacionamientoApi::class . ':traerCocheraMenosUsada');
      $this->get('/cocherasNoUtilizadas', \estacionamientoApi::class . ':traerCocherasNoUsadas');
      $this->get('/traermail/{email}', \estacionamientoApi::class . ':traerUno');
  })->add(\MWparaAutentificar::class . ':Verificarempleado');


  $app->group('/archivos', function () {
    
      $this->get('/excelEstacionados', \archivoApi::class . ':exportarExcelEstacionados');
      $this->get('/pdfEstacionados', \archivoApi::class . ':exportarPDFEstacionados');
  });


  $app->run();
