<?php 
	//require_once ("Producto.php");


class Archivo {

        public static function moveUploadedFile($uploadedFile, $email)
        {
            //mkdir('uploads/');
            $email = str_replace(" ", "_", $email);
            $extension = pathinfo($uploadedFile->getClientFilename(), PATHINFO_EXTENSION);
            $filename = trim($email) .'.'. $extension;

            $ruta = 'uploads/' . $filename;
            $uploadedFile->moveTo($ruta);
        
            return $ruta;
        }

        public static function moverFotoABackup($pathviejo, $email)
        {
            //mkdir("ProductosBorrados/");
            $extension = pathinfo($pathviejo, PATHINFO_EXTENSION);
            rename($pathviejo , "./ProductosBorrados/".trim($email)."-".date("Ymd_His").".".$extension);
        }
    }
 
?>