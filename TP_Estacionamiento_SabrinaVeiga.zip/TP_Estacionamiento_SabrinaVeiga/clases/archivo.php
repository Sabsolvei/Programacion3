<?php 
	//require_once ("Producto.php");


class Archivo {

        public static function moveUploadedFile($uploadedFile, $nombre)
        {
            //mkdir('uploads/');
            $nombre = str_replace(" ", "_", $nombre);
            $extension = pathinfo($uploadedFile->getClientFilename(), PATHINFO_EXTENSION);
            $filename = trim($nombre) .'.'. $extension;

            $ruta = 'uploads/' . $filename;
            $uploadedFile->moveTo($ruta);
        
            return $ruta;
        }

        public static function moverFotoABackup($pathviejo, $nombre)
        {
            //mkdir("ProductosBorrados/");
            $extension = pathinfo($pathviejo, PATHINFO_EXTENSION);
            rename($pathviejo , "./ProductosBorrados/".trim($nombre)."-".date("Ymd_His").".".$extension);
        }
    }
 
?>