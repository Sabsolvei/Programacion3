<?php
require_once 'empleado.php';
require_once 'archivo.php';


class empleadosApi //extends empleado //implements IApiUsable
{
	public function TraerUno($request, $response, $args) 
	{
			$id = $args['id'];
			$elempleado = empleado::TraerUnEmpleado($id);
			$newResponse = $response->withJson($elempleado, 200);  
			return $newResponse;
	}
	
	public function traerTodos($request, $response, $args) 
	{
			$todosLosempleados = empleado::TraerTodosLosempleados();
			$response = $response->withJson($todosLosempleados, 200);  
			return $response;
	}
	

	public function CargarUno($request, $response, $args) 
	{
		$ArrayDeParametros = $request->getParsedBody();
        // if(empleado::TraerUnEmpleadoPorMail($ArrayDeParametros['email']) != null) {
        //     return "El usuario ya esta registrado";
        // }
			
            $nombre = $ArrayDeParametros['nombre'];
            $apellido = $ArrayDeParametros['apellido'];
            $email = $ArrayDeParametros['email'];
			$turno = $ArrayDeParametros['turno'];
            $perfil = $ArrayDeParametros['perfil'];
            $fechaCreacion = date("Y/m/d H:i:s");
			$estado = "Activo";//$ArrayDeParametros['estado'];
			$clave = password_hash($ArrayDeParametros['clave'], PASSWORD_BCRYPT);

			$miEmpleado = new empleado();
            $miEmpleado->nombre=$nombre;
            $miEmpleado->apellido=$apellido;
            $miEmpleado->email=$email;
            $miEmpleado->clave=$clave;
			$miEmpleado->turno=$turno;
            $miEmpleado->perfil=$perfil;
            $miEmpleado->fechaCreacion=$fechaCreacion;
            $miEmpleado->estado=$estado;
			
            $ruta = $this->obtenerArchivo($request, $response, $email);
            if($ruta != NULL)
            {
                $miEmpleado->foto = $ruta;
                $miEmpleado->InsertarElempleadoParametros();
                $response->getBody()->write("Se guardo el Empleado. ");
            }
            else
            {
                $response->getBody()->write("Error al intentar guardar archivo. ");
            }

			return $response;
	}
	

    public function obtenerArchivo($request, $response, $email) 
	{
		$uploadedFiles = $request->getUploadedFiles();
		$uploadedFile = $uploadedFiles['archivo'];
		
		if ($uploadedFile->getError() === UPLOAD_ERR_OK) 
		{
			$ruta = archivo::moveUploadedFile($uploadedFile, $email);
			return $ruta;
		}
		else
		{
			return NULL;
		}	
	}

    public function ModificarUno($request, $response, $args) 
	{
			$objDelaRespuesta= new stdclass();
			$empleadoAModificar = new empleado();
			$ArrayDeParametros = $request->getParsedBody();

			if(isset($ArrayDeParametros['id']))
			{
				$empleadoAModificar = $empleadoAModificar->TraerUnEmpleado($ArrayDeParametros['id']);
				if($empleadoAModificar != NULL)
				{
					if(isset($ArrayDeParametros['nombre'])) {
					$empleadoAModificar->nombre = $ArrayDeParametros['nombre'];
					}
					if(isset($ArrayDeParametros['apellido'])) {
						$empleadoAModificar->apellido = $ArrayDeParametros['apellido'];
					}
					if(isset($ArrayDeParametros['email'])) {
						$empleadoAModificar->email = $ArrayDeParametros['email'];
					}
                    if(isset($ArrayDeParametros['clave'])) {
						$empleadoAModificar->clave = password_hash($ArrayDeParametros['clave'], PASSWORD_BCRYPT);
					}
                    if(isset($ArrayDeParametros['turno'])) {
						$empleadoAModificar->turno = $ArrayDeParametros['turno'];
                    }
                    if(isset($ArrayDeParametros['perfil'])) {
						$empleadoAModificar->perfil = $ArrayDeParametros['perfil'];
                    }
                    if(isset($ArrayDeParametros['estado'])) {
						$empleadoAModificar->estado = $ArrayDeParametros['estado'];
					}

					//PARA MODIFICAR IMAGEN DEBO PASAR EL METODO A POST (PARA PODER USAR FORM-DATA, PUT SOLO USA WWW-URLENCODED)
					// $ruta = $this->obtenerArchivo($request, $response, $empleadoAModificar->nombre);
					// if($ruta != 0) {
					// 	$empleadoAModificar->foto = $ruta;
					// }

					$resultado = $empleadoAModificar->ModificarEmpleadoParametros();
					$objDelaRespuesta->resultado=$resultado;
				}

				else { $objDelaRespuesta->resultado= "El email ingresado no existe."; }
			}
			
			else { $objDelaRespuesta->resultado= "Debe ingresar un email."; }

			return $response->withJson($objDelaRespuesta, 200);		
	}


    public function BorrarUno($request, $response, $args) 
    {
            $ArrayDeParametros = $request->getParsedBody(); //form-urlencoded
            $id=$ArrayDeParametros['id'];
            $empleado= new empleado();
            $empleado->id=$id;
            $cantidadDeBorrados=$empleado->Borrarempleado();

            $objDelaRespuesta= new stdclass();
            $objDelaRespuesta->cantidad=$cantidadDeBorrados;
            if($cantidadDeBorrados>0)
            {
                $objDelaRespuesta->resultado="El empleado con id: ".$id." fue eliminado exitosamente";
            }
            else
            {
                $objDelaRespuesta->resultado="no Borro nada!!!";
            }
            $newResponse = $response->withJson($objDelaRespuesta, 200);  
            return $newResponse;
    }
}