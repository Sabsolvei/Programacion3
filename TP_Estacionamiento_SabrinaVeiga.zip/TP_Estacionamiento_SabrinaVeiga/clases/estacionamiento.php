<?php
class estacionamiento
{
    public $id;
    public $patente;
    public $color;
    public $foto;
    public $idEmpleadoEntrada;
    public $fechaHoraIngreso;
    public $idEmpleadoSalida;
    public $fechaHoraEgreso;
    public $tiempoTranscurrido;
    public $importe;
    public $idCochera;
    
    

//TRAER Estacionamiento	
    public static function TraerTodosLosEstacionamientos()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta =$objetoAccesoDato->RetornarConsulta("select * from estacionamiento");
        $consulta->execute();

        return $consulta->fetchAll(PDO::FETCH_CLASS, "estacionamiento");
    }




    public static function TraerDatosEstacionamiento()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta =$objetoAccesoDato->RetornarConsulta("SELECT patente, idCochera, FechaHoraIngreso, FechaHoraEgreso, importe 
                                                        FROM estacionamiento
                                                        ORDER BY FechaHoraEgreso DESC");
        
        $consulta->execute();
        $array = $consulta->fetchAll(PDO::FETCH_ASSOC);

        return $array;
    }




    public static function TraerEstacionamientoOcupadoPorPatente($patente)
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta =$objetoAccesoDato->RetornarConsulta("SELECT * 
													    FROM estacionamiento 
													    WHERE patente = '$patente' AND fechaHoraEgreso is NULL");
        $consulta->execute();
        return $consulta->fetchAll(PDO::FETCH_CLASS, "estacionamiento");
    }

    public static function TraerCocheEstacionadoPorPatente($patente)
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta =$objetoAccesoDato->RetornarConsulta("SELECT * 
													    FROM estacionamiento 
													    WHERE patente = '$patente' 
                                                        AND fechaHoraIngreso is not NULL
                                                        AND fechaHoraEgreso is NULL");
        $consulta->execute();
        return $consulta->fetchAll(PDO::FETCH_CLASS, "estacionamiento");
    }
    

    public static function TraerCocheraMasUtilizada()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta =$objetoAccesoDato->RetornarConsulta("SELECT idCochera,COUNT(idCochera) AS Cantidad 
                                                        FROM estacionamiento
                                                        GROUP BY idCochera
                                                        HAVING COUNT(idCochera) = (SELECT MAX(cnt)
                                                                                   FROM (SELECT COUNT(idCochera) cnt
                                                                                         FROM estacionamiento
                                                                                         GROUP BY idCochera) AS t)");
        $consulta->execute();
        return $consulta->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function TraerCocheraMenosUtilizada()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta =$objetoAccesoDato->RetornarConsulta("SELECT idCochera,COUNT(idCochera) AS Cantidad 
                                                        FROM estacionamiento
                                                        GROUP BY idCochera
                                                        HAVING COUNT(idCochera) = (SELECT MIN(cnt)
                                                                                   FROM (SELECT COUNT(idCochera) cnt
                                                                                         FROM estacionamiento
                                                                                         GROUP BY idCochera) AS t)");
    
        $consulta->execute();
        return $consulta->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function TraerCocherasNoUtilizadas()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta =$objetoAccesoDato->RetornarConsulta("SELECT CO.id
													FROM cocheras CO 
													LEFT JOIN estacionamiento ES on CO.Id = ES.idCochera
													WHERE ES.idCochera is null");
    
        $consulta->execute();
        return $consulta->fetchAll(PDO::FETCH_ASSOC);
    }


//INSERTAR / MODIFICAR
    public function GuardarEstacionamiento()
    {
        if ($this->id>0) {
                $this->ModificarEstacionamientoParametros();
        } else {
            $this->InsertarElestacionamientoParametros();
        }
    }

    public static function TraerCochera($discapacitados)
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        if ($discapacitados=="true") {
            $consulta =$objetoAccesoDato->RetornarConsulta("select * from cocheras where discapacitados = 1 and disponibilidad = 1 limit 1");
            if ($consulta == null) {
                $consulta =$objetoAccesoDato->RetornarConsulta("select * from cocheras where discapacitados = 0 and disponibilidad = 1 limit 1");
            }
        } else {
            $consulta =$objetoAccesoDato->RetornarConsulta("select * from cocheras where discapacitados = 0 and disponibilidad = 1 limit 1");
        }
        $consulta->execute();
        $array = $consulta->fetchAll();
        return $array;
    }

    public function OcuparCochera()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta =$objetoAccesoDato->RetornarConsulta("
			update Cocheras 
			set disponibilidad=0
			WHERE id ='$this->idCochera'");
        return $consulta->execute();
    }

    public function DesocuparCochera()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta =$objetoAccesoDato->RetornarConsulta("
			update cocheras 
			set disponibilidad=1
			WHERE id ='$this->idCochera'");
        return $consulta->execute();
    }



//INSERTAR
    public function InsertarElEstacionamientoParametros()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta =$objetoAccesoDato->RetornarConsulta("INSERT into estacionamiento (patente, color, foto, idEmpleadoEntrada, fechaHoraIngreso, idCochera) values(:patente,:color,:foto,:idEmpleadoEntrada,:fechaHoraIngreso,:idCochera)");
        $consulta->bindValue(':patente', $this->patente, PDO::PARAM_STR);
        $consulta->bindValue(':color', $this->color, PDO::PARAM_STR);
        $consulta->bindValue(':foto', $this->foto, PDO::PARAM_STR);
        $consulta->bindValue(':idEmpleadoEntrada', $this->idEmpleadoEntrada, PDO::PARAM_INT);
        $consulta->bindValue(':fechaHoraIngreso', $this->fechaHoraIngreso, PDO::PARAM_STR);
        $consulta->bindValue(':idCochera', $this->idCochera, PDO::PARAM_STR);
        $consulta->execute();
        return $objetoAccesoDato->RetornarUltimoIdInsertado();
    }

//MODIFICAR
//

    public function ModificarEstacionamiento()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta =$objetoAccesoDato->RetornarConsulta("
				UPDATE estacionamiento 
				set idEmpleadoSalida='$this->idEmpleadoSalida',
				fechaHoraEgreso='$this->fechaHoraEgreso',
				tiempoTranscurrido='$this->tiempoTranscurrido',
				importe='$this->importe'
				WHERE patente ='$this->patente' and fechaHoraIngreso ='$this->fechaHoraIngreso'");
        $consulta->execute();
        return estacionamiento::TraerEstacionamientoOcupadoPorPatente($this->patente);
    }
    
    // public function DatosVehiculosSalida($vehiculo)
    // {
    // 	return  "{'patente': '" . $vehiculo->patente . "', 'color':'" . $vehiculo->color ."', 'foto': '".$vehiculo->foto . "', 'importe':'".$vehiculo->importe."'}";
    // }

    public function CalcularImporte()
    {
        $importe = 0;
        $estadiaCompletaSegundos = (strtotime($this->fechaHoraEgreso) - strtotime($this->fechaHoraIngreso)); //SEGUNDOS
        $estadiaCompletaMinutos = $estadiaCompletaSegundos / 60; //MINUTOS // dividido 3600 da horas, dividido 60 da minutos, dividido 86400 da dias
        $estadiaCompletaHoras = $estadiaCompletaMinutos / 60; //HORAS CON DECIMALES
        $estadiaCompletaDias = $estadiaCompletaHoras / 24; //DIAS CON DECIMALES
        
        /////CALCULO IMPORTE ESTADIA COMPLETA
        $this->tiempoTranscurrido = (int)$estadiaCompletaDias . " DIAS | ";
        $importe = (int)$estadiaCompletaDias * 170;
        
        //EXTRAIGO SOBRANTES DE HORAS DE DIAS
        $horasSobrantes = estacionamiento::ExtraerDosDecimales($estadiaCompletaDias);
        $horas = $horasSobrantes *24 / 100; //HORAS EXTRAIDAS DEL DECIMAL DE DIAS
        $this->tiempoTranscurrido = $this->tiempoTranscurrido . round($horas, 0, PHP_ROUND_HALF_UP) . " HS";
        ;

        /////CALCULO IMPORTE MEDIA ESTADIA
        $mediaEstadiaConDecimales = $horas / 12;
        $importe = $importe + ((int)$mediaEstadiaConDecimales) * 90;
        
        //EXTRAIGO SOBRANTES DE HORAS DE MEDIA ESTADIA
        $horasSobrantes = estacionamiento::ExtraerDosDecimales($mediaEstadiaConDecimales);
        
        /////CALCULO HORAS SOBRANTES DE MEDIA ESTADIA
        $horas = $horasSobrantes *12 / 100; //HORAS EXTRAIDAS DEL DECIMAL DE MEDIA ESTADIA
        $importe = $importe + round($horas, 0, PHP_ROUND_HALF_UP) * 10;
        $this->importe = $importe;
    }
    
    public static function ExtraerDosDecimales($diasUHoras)
    {
        $horasStr = (string)$diasUHoras;
        $horasSobrantesStr = substr($horasStr, strpos($horasStr, "."));
        $horasSobrantesStr = (str_replace(".", "", $horasSobrantesStr));
        $horasSobrantes = substr($horasSobrantesStr, 0, 2);
        if (strlen($horasSobrantes) == 1) {
            $horasSobrantes = $horasSobrantes . '0';
        }
        return (int)$horasSobrantes;
    }

//BORRAR
    public function BorrarEstacionamiento()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $estacionamiento = estacionamiento::TraerEstacionamientoOcupadoPorPatente($this->patente);
        if (!empty($estacionamiento)) {
               archivo::moverFotoABackup($estacionamiento->ruta, $this->patente, 'backupFotos/');
        }
       
        $consulta = $objetoAccesoDato->RetornarConsulta("DELETE
                                                         FROM Estacionamiento
                                                         WHERE patente=:patente AND fechaHoraIngreso=:fechaIngreso");
        $consulta->bindValue(':patente', $this->patente, PDO::PARAM_STR);
        $consulta->bindValue(':fechaIngreso', $this->fechaHoraIngreso, PDO::PARAM_STR);
        $consulta->execute();
        return $consulta->rowCount();
    }


    public function mostrarDatos()
    {
        return "Metodo mostrar:" . $this->email . "  " . $this->patenteTraerEstacionamientoOcupadoPorPatente ."  " . $this->estacionamiento . "  " . $this->ruta;
    }
}
