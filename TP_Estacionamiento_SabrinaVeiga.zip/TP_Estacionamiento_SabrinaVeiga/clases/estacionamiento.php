<?php
class estacionamiento
{
  	public $id;
    public $patente;
    public $color;
	public $foto;
	public $idEmpleadoEntrada;
    public $fechaHoraIngreso;
    public $idEmpleadoSalida;
	public $fechaHoraEgreso;
	public $tiempoTranscurrido;
	public $importe;
	public $idCochera;
	
	

//TRAER Estacionamiento	
public static function TraerTodosLosEstacionamientos()
{
	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	$consulta =$objetoAccesoDato->RetornarConsulta("select idCochera, FechaHora_Ingreso, FechaHora_Egreso, importe from estacionamiento");
	$consulta->execute();			
	return $consulta->fetchAll(PDO::FETCH_CLASS, "estacionamiento");		
}

public static function TraerEstacionamientoPorPatente($patente)
{
	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	$consulta =$objetoAccesoDato->RetornarConsulta("select * from estacionamiento where email = '$patente'");
	$consulta->execute();			
	return $consulta->fetchAll(PDO::FETCH_CLASS, "estacionamiento");		
}

//INSERTAR / MODIFICAR
	public function GuardarEstacionamiento()
	{
		if($this->id>0)
			{
				$this->ModificarEstacionamientoParametros();
			}else {
				$this->InsertarElestacionamientoParametros();
			}
	}

	public function TraerCochera($discapacitados)
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		if($discapacitados)
		{
			$consulta =$objetoAccesoDato->RetornarConsulta("select * from cocheras where discapacitados = 'true' and disponibilidad = 'true' limit 1");
		} 
		else 
		{
			$consulta =$objetoAccesoDato->RetornarConsulta("select * from cocheras where discapacitados = 'false' and disponibilidad = 'true' limit 1");
		}
		
		$consulta->execute();			
		return $consulta->fetchAll(PDO::FETCH_CLASS, "cochera");
	}

	public function OcuparCochera()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("
			update Cocheras 
			set disponibilidad='false'
			WHERE id ='$this->idCochera'");
		return $consulta->execute();
	}

	public function DesocuparCochera()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("
			update cocheras 
			set disponibilidad='true'
			WHERE id ='$this->idCochera'");
		return $consulta->execute();
	}



//INSERTAR
	public function InsertarElEstacionamientoParametros()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("INSERT into estacionamiento (patente, color, foto, idEmpleadoEntrada, FechaHora_Ingreso, idCochera) values(:patente,:color,:foto,:idEmpleadoEntrada,:fechaHoraIngreso,:idCochera)");
		$consulta->bindValue(':patente', $this->patente, PDO::PARAM_STR);
		$consulta->bindValue(':color', $this->color, PDO::PARAM_STR);
		$consulta->bindValue(':foto', $this->foto, PDO::PARAM_STR);
		$consulta->bindValue(':idEmpleadoEntrada', $this->idEmpleadoEntrada, PDO::PARAM_INT);
		$consulta->bindValue(':fechaHoraIngreso', $this->fechaHoraIngreso, PDO::PARAM_STR);
		$consulta->bindValue(':idCochera', $this->idCochera, PDO::PARAM_STR);
		$consulta->execute();		
		return $objetoAccesoDato->RetornarUltimoIdInsertado();
	}
	

//MODIFICAR
//

	public function Modificarestacionamiento()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("
			update estacionamiento 
			set idEmpleadoSalida='$this->idEmpleadoSalida',
			FechaHora_Egreso='$this->fechaHoraEgreso',
			TiempoTranscurrido='$this->tiempoTranscurrido'
			Importe='$this->importe'
			WHERE patente ='$this->patente'");
		return $consulta->execute();
	}

//BORRAR
	// public function BorrarEstacionamiento()
	// {
	//    $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
	//    $Estacionamiento = estacionamiento::TraerestacionamientoPorTitulo($this->titulo);
	//    if($Estacionamiento != NULL)
	//    {
	// 	   foreach ($Estacionamiento as $estacionamiento) 
	// 	   {
	// 		   archivo::moverFotoABackup($estacionamiento->ruta, $this->titulo);
	// 	   }
		  
	//    }
	   
	//    $consulta = $objetoAccesoDato->RetornarConsulta("
	// 	   delete 
	// 	   from Estacionamiento 				
	// 	   WHERE titulo=:titulo");	
	//    $consulta->bindValue(':titulo', $this->titulo, PDO::PARAM_STR);		
	//    $consulta->execute();
	//    return $consulta->rowCount();
	// }


	public function mostrarDatos()
	{
	  	return "Metodo mostrar:" . $this->email . "  " . $this->titulo ."  " . $this->estacionamiento . "  " . $this->ruta;
	}

}