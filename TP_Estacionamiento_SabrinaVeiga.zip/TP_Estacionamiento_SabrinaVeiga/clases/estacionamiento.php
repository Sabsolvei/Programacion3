<?php
class estacionamiento
{
  	public $id;
    public $patente;
    public $color;
	public $foto;
	public $idEmpleadoEntrada;
    public $fechaHoraIngreso;
    public $idEmpleadoSalida;
	public $fechaHoraEgreso;
	public $tiempoTranscurrido;
	public $importe;
	public $idCochera;
	
	

//TRAER Estacionamiento	
public static function TraerTodosLosEstacionamientos()
{
	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	$consulta =$objetoAccesoDato->RetornarConsulta("select idCochera, FechaHora_Ingreso, FechaHora_Egreso, importe from estacionamiento");
	$consulta->execute();			
	return $consulta->fetchAll(PDO::FETCH_CLASS, "estacionamiento");		
}

public static function TraerEstacionamientoOcupadoPorPatente($patente)
{
	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	$consulta =$objetoAccesoDato->RetornarConsulta("SELECT * 
													FROM estacionamiento 
													WHERE patente = '$patente' AND fechaHoraEgreso IS NULL");
	$consulta->execute();			
	$cantRow = $consulta->rowCount();
	return $cantRow;		
}

//INSERTAR / MODIFICAR
	public function GuardarEstacionamiento()
	{
		if($this->id>0)
			{
				$this->ModificarEstacionamientoParametros();
			}else {
				$this->InsertarElestacionamientoParametros();
			}
	}

	public static function TraerCochera($discapacitados)
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		if($discapacitados=="true")
		{
			$consulta =$objetoAccesoDato->RetornarConsulta("select * from cocheras where discapacitados = 1 and disponibilidad = 1 limit 1");
		} 
		else 
		{
			$consulta =$objetoAccesoDato->RetornarConsulta("select * from cocheras where discapacitados = 0 and disponibilidad = 1 limit 1");
		}
		$consulta->execute();
		$array = $consulta->fetchAll();
		return $array;
	}

	public function OcuparCochera()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("
			update Cocheras 
			set disponibilidad=0
			WHERE id ='$this->idCochera'");
		return $consulta->execute();
	}

	public function DesocuparCochera()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("
			update cocheras 
			set disponibilidad='true'
			WHERE id ='$this->idCochera'");
		return $consulta->execute();
	}



//INSERTAR
	public function InsertarElEstacionamientoParametros()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("INSERT into estacionamiento (patente, color, foto, idEmpleadoEntrada, fechaHoraIngreso, idCochera) values(:patente,:color,:foto,:idEmpleadoEntrada,:fechaHoraIngreso,:idCochera)");
		$consulta->bindValue(':patente', $this->patente, PDO::PARAM_STR);
		$consulta->bindValue(':color', $this->color, PDO::PARAM_STR);
		$consulta->bindValue(':foto', $this->foto, PDO::PARAM_STR);
		$consulta->bindValue(':idEmpleadoEntrada', $this->idEmpleadoEntrada, PDO::PARAM_INT);
		$consulta->bindValue(':fechaHoraIngreso', $this->fechaHoraIngreso, PDO::PARAM_STR);
		$consulta->bindValue(':idCochera', $this->idCochera, PDO::PARAM_STR);
		$consulta->execute();		
		return $objetoAccesoDato->RetornarUltimoIdInsertado();
	}
	

//MODIFICAR
//

	public function Modificarestacionamiento()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("
			update estacionamiento 
			set idEmpleadoSalida='$this->idEmpleadoSalida',
			FechaHora_Egreso='$this->fechaHoraEgreso',
			TiempoTranscurrido='$this->tiempoTranscurrido'
			Importe='$this->importe'
			WHERE patente ='$this->patente'");
		return $consulta->execute();
	}

//BORRAR
	// public function BorrarEstacionamiento()
	// {
	//    $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
	//    $Estacionamiento = estacionamiento::TraerestacionamientoPorTitulo($this->titulo);
	//    if($Estacionamiento != NULL)
	//    {
	// 	   foreach ($Estacionamiento as $estacionamiento) 
	// 	   {
	// 		   archivo::moverFotoABackup($estacionamiento->ruta, $this->titulo);
	// 	   }
		  
	//    }
	   
	//    $consulta = $objetoAccesoDato->RetornarConsulta("
	// 	   delete 
	// 	   from Estacionamiento 				
	// 	   WHERE titulo=:titulo");	
	//    $consulta->bindValue(':titulo', $this->titulo, PDO::PARAM_STR);		
	//    $consulta->execute();
	//    return $consulta->rowCount();
	// }


	public function mostrarDatos()
	{
	  	return "Metodo mostrar:" . $this->email . "  " . $this->titulo ."  " . $this->estacionamiento . "  " . $this->ruta;
	}

}