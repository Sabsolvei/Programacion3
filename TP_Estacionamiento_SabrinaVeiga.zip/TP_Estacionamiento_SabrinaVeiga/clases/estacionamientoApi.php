<?php
require_once 'estacionamiento.php';
require_once 'archivo.php';
require_once 'empleado.php';
//require_once 'IApiUsable.php';

class estacionamientoApi extends estacionamiento //implements IApiUsable
{

    public function TraerUno($request, $response, $args)
    {
            $patente = $args['patente'];
            $estacionamientos=estacionamiento::TraerEstacionamientoPorPatente($patente);
            $newResponse = $response->withJson($estacionamientos, 200);
            return $newResponse;
    }
    
    public function traerTodos($request, $response, $args)
    {
            $todosLosestacionamientos=estacionamiento::TraerTodosLosEstacionamientos();
            $response = $response->withJson($todosLosestacionamientos, 200);
            return $response;
    }


    public function CargarUno($request, $response, $args)
    {
		$ArrayDeParametros = $request->getParsedBody();
		$cochera = TraerCochera($ArrayDeParametros['discapacitados']);
		if ($cochera != false) 
		{
            $idCochera = $cochera->id;
            $patente = $ArrayDeParametros['patente'];
            $color = $ArrayDeParametros['color'];
			
            $data = AutentificadorJWT::ObtenerData($request->getHeader('token'));
            $idEmpleadoEntrada = $data['Empleado']->id;
			$fechaHoraIngreso = date("Y/m/d H:i:s");
			
			$miEstacionamiento = new estacionamiento();
            $miEstacionamiento->idCochera=$idCochera;
            $miEstacionamiento->patente=$patente;
            $miEstacionamiento->color=$color;
            $miEstacionamiento->idEmpleadoEntrada=$idEmpleadoEntrada;
			$miEstacionamiento->fechaHoraIngreso=$fechaHoraIngreso;
			
            $ruta = $this->obtenerArchivo($request, $response, $patente);
            if($ruta != NULL)
            {
                $miEstacionamiento->foto = $ruta;
				$miEstacionamiento->InsertarElEstacionamientoParametros();
				$miEstacionamiento->OcuparCochera();
                $response->getBody()->write("Se guardo el vehiculo. ");
            }
            else
            {
                $response->getBody()->write("Error al intentar guardar la foto. ");
			}
		}
		else
		{
			$response->getBody()->write("No hay cocheras disponibles. ");
		}

			return $response;
    }

//IdEmpleadaSalida	FechaHora_Egreso	TiempoTranscurrido	Importe	Id_Cochera


    public function obtenerArchivo($request, $response, $patente)
    {
        $uploadedFiles = $request->getUploadedFiles();
        $uploadedFile = $uploadedFiles['archivo']; //se obtiene asi por si sube mas de un archivo
        
        if ($uploadedFile->getError() === UPLOAD_ERR_OK) {
            $ruta = archivo::moveUploadedFile($uploadedFile, $patente);
            return $ruta;
        } else {
            return null;
        }
    }
    
     
    public function ModificarUno($request, $response, $args)
    {
            $objDelaRespuesta= new stdclass();
            $estacionamientoAModificar = new estacionamiento();
            $ArrayDeParametros = $request->getParsedBody();

		if (isset($ArrayDeParametros['patente'])) 
		{
			$estacionamientoAModificar = $estacionamientoAModificar->TraerEstacionamientoPorPatente($ArrayDeParametros['patente']);
			if ($estacionamientoAModificar != null) 
			{
				$estacionamientoAModificar->DesocuparCochera();
				$data = AutentificadorJWT::ObtenerData($request->getHeader('token'));
				$estacionamientoAModificar->idEmpleadoSalida = $data['Empleado']->id;
				$estacionamientoAModificar->fechaHoraEgreso = date("Y/m/d H:i:s");

				$estacionamientoAModificar->tiempoTranscurrido = (strtotime($estacionamientoAModificar->fechaHoraEgreso) - strtotime($estacionamientoAModificar->fechaHoraIngreso))/60;
				$tiempo = $estacionamientoAModificar->tiempoTranscurrido;
				if($tiempo == 12){
					$estacionamientoAModificar->importe = 90;
				}elseif($tiempo == 24){
					$estacionamientoAModificar->importe = 170;
				}else{
					$estacionamientoAModificar->importe = $tiempo * 10;
				}

                $estacionamientoAModificar->ModificarEstacionamiento();
                $objDelaRespuesta->resultado= "El vehiculo fue despachado con exito.";
			} 
			else 
			{
                $objDelaRespuesta->resultado= "La patente ingresada no existe.";
            }
		} 
		else 
		{
            $objDelaRespuesta->resultado= "Debe ingresar la patente.";
        }

        return $response->withJson($objDelaRespuesta, 200);
    }
	
	public function CalcularImporte(){
		$this->egreso = date("Y/m/d H:i:s");
        $tiempoMin =(strtotime($this->egreso) - strtotime($this->ingreso))/60;
        if($tiempoMin <= 60){
        	$this->importe = 10;
        }elseif($tiempoMin > 60 && $tiempoMin <= 720){
        	$this->importe = 90;
        }else{
        	$this->importe = 170;
        }
    }



    public function BorrarUno($request, $response, $args)
    {
            $ArrayDeParametros = $request->getParsedBody(); //form-urlencoded
            $titulo = $ArrayDeParametros['titulo'];

            $estacionamiento = new estacionamiento();
            $Comentario->titulo = $titulo;
            $cantidadDeBorrados = $Comentario->BorrarComentario();

            $objDelaRespuesta = new stdclass();
            $objDelaRespuesta->cantidad = $cantidadDeBorrados;
        if ($cantidadDeBorrados > 0) {
            $objDelaRespuesta->resultado = "El Comentario con titulo: ".$titulo." fue eliminado exitosamente";
        } else {
            $objDelaRespuesta->resultado = "No Borro nada!!!";
        }
            $newResponse = $response->withJson($objDelaRespuesta, 200);
            return $newResponse;
    }





    public function generarTabla($request, $response, $args)
    {
 //GET
                $comentarios;
                $usuarios;
                $grilla = '<table class="table">
				<thead style="background:rgb(14, 26, 112);color:#fff;">
					<tr>
						<th>  EMAIL  	</th>
						<th>  EDAD   	</th>
						<th>  TITULO	</th>
						<th>  COMENTARIO</th>
						<th>  FOTO		</th>
					</tr>  
				</thead>';

        if (isset($args['titulo'])) {
            $titulo = $args['titulo'];
            $comentarios = comentario::TraerComentarioPorTitulo($titulo);
            //$usuarios = usuario::TraerUnUsuarioPorMail($email);
        } elseif (isset($args['email'])) {
            $email = $args['email'];
            $comentarios = comentario::TraerComentariosPorMail($email);
            //$usuarios = usuario::TraerUnUsuarioPorMail($email);
        } else {
            $comentarios = comentario::TraerTodosLosComentarios();
        }

        foreach ($comentarios as $comentario) {
            $edad = "-";
            $user = usuario::TraerUnUsuarioPorMail($comentario->email);
            if ($user != null) {
                $edad = $user->edad;
            }

            $grilla .= "<tr>
				<td>".$comentario->email."</td>
				<td>".$edad."</td>
				<td>".$comentario->titulo."</td>
				<td>".$comentario->comentario."</td>
				<td><img src=" . (isset($args['titulo']) ? '../../' : (isset($args['email'])? '../': '' )) .'../'. $comentario->ruta." width='100px' height='100px'/></td>
				</tr>";
        }
                return $grilla;
    }
}
