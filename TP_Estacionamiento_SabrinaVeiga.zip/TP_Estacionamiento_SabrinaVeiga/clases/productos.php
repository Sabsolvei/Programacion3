<?php
class producto
{
	public $id;
 	public $nombre;
  	public $precio;


//TRAER productoS
public static function TraerTodosLosproductos()
{
	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	$consulta =$objetoAccesoDato->RetornarConsulta("select * from productos");
	$consulta->execute();			
	return $consulta->fetchAll(PDO::FETCH_CLASS, "producto");		
}

public static function TraerUnproducto($id) 
{
	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	$consulta =$objetoAccesoDato->RetornarConsulta("select id, nombre, precio from productos where id = $id");
	$consulta->execute();
	$productoBuscado= $consulta->fetchObject('producto');
	return $productoBuscado;				
}

public static function TraerUnproductoPorNombre($nombre) 
{
	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	$consulta =$objetoAccesoDato->RetornarConsulta("select id, nombre, precio from productos where nombre = '$nombre'");
	$consulta->execute();
	$productoBuscado= $consulta->fetchObject('producto');
	return $productoBuscado;				
}





//INSERTAR MODIFICAR
	public function Guardarproducto()
	{
		if($this->id>0)
			{
				$this->ModificarproductoParametros();
			}else {
				$this->InsertarElproductoParametros();
			}
	}



//INSERTAR
	public function InsertarElproductoParametros()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("INSERT into productos  (nombre,precio) values(:nombre,:precio)");
		$consulta->bindValue(':nombre',$this->nombre, PDO::PARAM_STR);
		$consulta->bindValue(':precio', $this->precio, PDO::PARAM_INT);
		$consulta->execute();		
		return $objetoAccesoDato->RetornarUltimoIdInsertado();
	}

	// public function InsertarElproducto()
	// {
	// 	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	// 	$consulta =$objetoAccesoDato->RetornarConsulta("INSERT into productos (nombre,precio)values('$this->nombre','$this->precio','$this->edad','$this->perfil','$this->clave')");
	// 	$consulta->execute();
	// 	return $objetoAccesoDato->RetornarUltimoIdInsertado();
	// }




//MODIFICAR
	public function ModificarproductoParametros()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();

		$consulta =$objetoAccesoDato->RetornarConsulta("
			update productos 
			set nombre=:nombre,
			precio=:precio
			WHERE id=:id");
		$consulta->bindValue(':nombre',$this->nombre, PDO::PARAM_STR);
        $consulta->bindValue(':precio', $this->precio, PDO::PARAM_INT);
        $consulta->bindValue(':id', $this->id, PDO::PARAM_INT);
		return $consulta->execute();
	}

	public function Modificarproducto()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("
			update productos 
			set nombre='$this->nombre',
			precio='$this->precio',
			WHERE id='$this->id'");
		return $consulta->execute();
	}




//BORRAR
  	public function Borrarproducto()
	 {
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("
			delete 
			from productos 				
			WHERE id=:id");	
		$consulta->bindValue(':id',$this->id, PDO::PARAM_INT);		
		$consulta->execute();
		return $consulta->rowCount();
	 }

	// public static function BorrarUsuarioPorprecio($precio)
	//  {
	// 	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	// 	$consulta =$objetoAccesoDato->RetornarConsulta("
	// 		delete 
	// 		from productos 				
	// 		WHERE precio=:precio");	
	// 	$consulta->bindValue(':precio',$precio, PDO::PARAM_STR);		
	// 	$consulta->execute();
	// 	return $consulta->rowCount();
    //  }
     
		 



//VERIFICAR USUARIO precio/ CLAVE
	public static function verificarUsuarioPorMail($precio)
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
		$resp = new stdClass();
		$consulta =$objetoAccesoDato->RetornarConsulta("select * from productos where email = '$email'");
		$consulta->execute();
		$usuario= $consulta->fetchObject('usuario');
		return $usuario;
	}

	public static function esValido($email, $clave) 
	{
		$usuario= $this->verificarUsuarioPorMail($email);
		if($usuario != NULL)
		{
			$verify = password_verify($clave, $usuario->clave);
			if($verify)
			{
				$resp->usuario = $usuario;
				$resp->msj = "Bienvenido ". $usuario->nombre . "!";
				$resp->perfil = $usuario->perfil;
				$resp->estado = 1;
			}
			else
			{
				$resp->msj = "Password incorrecta";
				$resp->estado = 0;
			}
		}
		else
		{
			$resp->msj = "Email no registrado";
			$resp->estado = 0;
		}
		
		return $resp;		
	}

	

	public function mostrarDatos()
	{
	  	return "Metodo mostrar:".$this->nombre."  ".$this->email."  ".$this->edad."  ".$this->perfil."  ".$this->clave;
	}

}