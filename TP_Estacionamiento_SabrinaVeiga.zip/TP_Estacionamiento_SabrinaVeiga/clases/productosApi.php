<?php
require_once 'productos.php';
//require_once 'IApiUsable.php';

class productosApi //extends producto //implements IApiUsable
{
	public function TraerUno($request, $response, $args) 
	{
			$id = $args['id'];
			$elproducto = producto::TraerUnproducto($id);
			$newResponse = $response->withJson($elproducto, 200);  
			return $newResponse;
	}
	
	public function traerTodos($request, $response, $args) 
	{
			$todosLosproductos = producto::TraerTodosLosproductos();
			$response = $response->withJson($todosLosproductos, 200);  
			return $response;
	}
	

	public function CargarUno($request, $response, $args) 
	{
			$ArrayDeParametros = $request->getParsedBody();
			$nombre = $ArrayDeParametros['nombre'];
			$precio = $ArrayDeParametros['precio'];
			
			$miproducto = new producto();
			$miproducto->nombre=$nombre;
			$miproducto->precio=$precio;

			$miproducto->InsertarElproductoParametros();

			$response->getBody()->write("se guardo el producto");

			return $response;
	}
	



	public function ModificarUno($request, $response, $args) 
	{
			$ArrayDeParametros = $request->getParsedBody();
		
			$productoAModificar = new producto();
			$productoAModificar = $productoAModificar->TraerUnproductoPorNombre($ArrayDeParametros['nombre']);
			if(isset($ArrayDeParametros['precio']))
			{
				$productoAModificar->precio = $ArrayDeParametros['precio'];
			}

			$resultado =$productoAModificar->ModificarproductoParametros();
			$objDelaRespuesta= new stdclass();
			$objDelaRespuesta->resultado=$resultado;
			return $response->withJson($objDelaRespuesta, 200);		
	}




	public function BorrarUno($request, $response, $args) 
	{
			$ArrayDeParametros = $request->getParsedBody(); //form-urlencoded
			$id=$ArrayDeParametros['id'];
			$producto= new producto();
			$producto->id=$id;
			$cantidadDeBorrados=$producto->Borrarproducto();

			$objDelaRespuesta= new stdclass();
			$objDelaRespuesta->cantidad=$cantidadDeBorrados;
			if($cantidadDeBorrados>0)
			{
					$objDelaRespuesta->resultado="El producto con id: ".$id." fue eliminado exitosamente";
			}
			else
			{
				$objDelaRespuesta->resultado="no Borro nada!!!";
			}
			$newResponse = $response->withJson($objDelaRespuesta, 200);  
			return $newResponse;
	}

}