define({
  "name": "",
  "version": "0.0.0",
  "description": "",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2017-12-05T15:46:06.040Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
