<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once './composer/vendor/autoload.php';
require_once './clases/AccesoDatos.php';
require_once './clases/empleadosApi.php';
require_once './clases/estacionamientoApi.php';
require_once './clases/loginApi.php';
require_once './clases/MWparaAutentificar.php';
require_once './clases/MWparaCors.php';
require_once './clases/AutentificadorJWT.php';

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new \Slim\App(["settings" => $config]);



$app->post('/ingreso/', \loginApi::class . ':login');


/*LLAMADA A METODOS DE INSTANCIA DE UNA CLASE*/
$app->group('/empleado', function () {   

  $this->get('/', \empleadosApi::class . ':traerTodos');
  $this->get('/{id}', \empleadosApi::class . ':traerUno');//->name('traerempleado');
  $this->delete('/', \empleadosApi::class . ':BorrarUno');//->redirect($app->urlFor('traerempleado'));
  $this->put('/', \empleadosApi::class . ':ModificarUno');
  $this->post('/', \empleadosApi::class . ':CargarUno');

});//->add(\MWparaAutentificar::class . ':Verificarempleado');

$app->group('/estacionamiento', function () {   
  
    $this->get('/', \estacionamientoApi::class . ':traerTodos');
    $this->get('/traermail/{email}', \estacionamientoApi::class . ':traerUno');
    $this->delete('/', \estacionamientoApi::class . ':BorrarUno');
    $this->put('/', \estacionamientoApi::class . ':ModificarUno');
    $this->post('/', \estacionamientoApi::class . ':CargarUno');
    $this->get('/grilla[/{email}[/{titulo}]]', \estacionamientoApi::class . ':generarTabla');//->add(\MWparaCors::class . ':HabilitarCORS4200');

  });//->add(\MWparaAutentificar::class . ':Verificarempleado');


$app->run();

// $_SERVER["REMOTE_ADDR"];